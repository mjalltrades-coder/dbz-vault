const assert=require('node:assert/strict'),M=require('../app/src/main/assets/price-history.js');
const x=(price,qty=1,source='tcgplayer_market',kind='market')=>({price,qty,source,kind,identity:'NM',confirmed:false});
let d=M.compare({a:x(10,2)},{a:x(12,3)});assert.deepEqual(d,{price:4,quantity:12,coverage:0,revaluation:0,total:16});
d=M.compare({a:x(10,3)},{a:x(12,2)});assert.equal(d.price,4);assert.equal(d.quantity,-10);assert.equal(d.total,-6);
assert.equal(M.compare({a:x(null,2)},{a:x(10,2)}).coverage,20);
assert.equal(M.compare({a:x(10)},{a:x(20,1,'ebay_asking','asking')}).revaluation,10);
assert.equal(M.compare({a:x(10,1,'manual','manual')},{a:x(15,1,'manual','manual')}).price,0);
assert.equal(M.category({price:10,source:'tcgplayer_market',normal_price_fallback:true}),'fallback');
assert.equal(M.category({price:10,source:'ebay_asking'}),'asking');
assert.equal(M.category(null),'unpriced');
for(let i=0;i<1000;i++){const a={a:x(Math.random()*100,Math.ceil(Math.random()*5)),b:x(10)},b={a:x(Math.random()*100,Math.ceil(Math.random()*5)),c:x(30)};d=M.compare(a,b);assert.ok(Math.abs(d.total-d.price-d.quantity-d.coverage-d.revaluation)<1e-8);}
console.log('History attribution and 1000 reconciliation cases passed');
