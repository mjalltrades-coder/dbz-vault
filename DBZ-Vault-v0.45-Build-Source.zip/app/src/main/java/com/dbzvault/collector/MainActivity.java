package com.dbzvault.collector;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.io.InputStream;

public class MainActivity extends Activity {
  private WebView web;
  private volatile java.io.File scanFile;
  private java.io.File exportFile;
  private java.io.OutputStream exportStream;
  private String exportId,exportName,exportMime;
  private long exportSize;
  private PermissionRequest pendingCamera;
  private void exportNotice(String message){runOnUiThread(()->{android.widget.Toast.makeText(this,message,android.widget.Toast.LENGTH_LONG).show();if(web!=null)web.evaluateJavascript("window.dbzExportResult && window.dbzExportResult("+org.json.JSONObject.quote(message)+")",null);});}
  private void clearExport(){try{if(exportStream!=null)exportStream.close();}catch(Exception ignored){}exportStream=null;if(exportFile!=null)exportFile.delete();exportFile=null;exportId=null;}

  private ValueCallback<Uri[]> pendingFiles;
  private static final int CAMERA_REQ=20, FILE_REQ=21, SCAN_REQ=22, EXPORT_REQ=23;
  private final com.google.mlkit.vision.text.TextRecognizer reader=com.google.mlkit.vision.text.TextRecognition.getClient(com.google.mlkit.vision.text.latin.TextRecognizerOptions.DEFAULT_OPTIONS);
  private final java.util.concurrent.ExecutorService work=java.util.concurrent.Executors.newSingleThreadExecutor();
  private final java.util.concurrent.ExecutorService pricingWork=java.util.concurrent.Executors.newSingleThreadExecutor();
  private static final String VALO_ALIAS="dbz-vault-valodata-aes-v1",VALO_PREFS="dbz-vault-secret-v1";
  private SharedPreferences valoPrefs(){return getSharedPreferences(VALO_PREFS,MODE_PRIVATE);}
  private SecretKey valoSecret()throws Exception{
    KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
    if(store.containsAlias(VALO_ALIAS))return (SecretKey)store.getKey(VALO_ALIAS,null);
    KeyGenerator generator=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
    generator.init(new KeyGenParameterSpec.Builder(VALO_ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setRandomizedEncryptionRequired(true).build());
    return generator.generateKey();
  }
  private synchronized boolean saveValoSecret(String key){
    try{if(key==null||!(key.startsWith("vd_test_")||key.startsWith("vd_live_"))||key.length()<20||key.length()>300)return false;Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,valoSecret());byte[] encrypted=cipher.doFinal(key.getBytes(StandardCharsets.UTF_8));return valoPrefs().edit().putString("iv",android.util.Base64.encodeToString(cipher.getIV(),android.util.Base64.NO_WRAP)).putString("value",android.util.Base64.encodeToString(encrypted,android.util.Base64.NO_WRAP)).commit();}catch(Exception e){return false;}
  }
  private synchronized String readValoSecret(){
    try{String iv=valoPrefs().getString("iv",null),value=valoPrefs().getString("value",null);if(iv==null||value==null)return "";Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,valoSecret(),new GCMParameterSpec(128,android.util.Base64.decode(iv,android.util.Base64.NO_WRAP)));return new String(cipher.doFinal(android.util.Base64.decode(value,android.util.Base64.NO_WRAP)),StandardCharsets.UTF_8);}catch(Exception e){return "";}
  }
  private String valoGet(String path,String key)throws Exception{
    HttpURLConnection c=(HttpURLConnection)new URL("https://api.valotcg.com"+path).openConnection();c.setRequestMethod("GET");c.setConnectTimeout(12000);c.setReadTimeout(15000);c.setRequestProperty("Authorization","Bearer "+key);c.setRequestProperty("Accept","application/json");
    try{int code=c.getResponseCode();InputStream stream=code>=200&&code<300?c.getInputStream():c.getErrorStream();if(stream==null)throw new java.io.IOException("HTTP "+code);java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();try(InputStream in=stream){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){if(out.size()+n>2*1024*1024)throw new java.io.IOException("Valo response too large");out.write(b,0,n);}}if(code<200||code>=300)throw new java.io.IOException("Valo HTTP "+code);return out.toString("UTF-8");}finally{c.disconnect();}
  }
  private static String norm(String s){return s==null?"":s.replaceAll("[^A-Za-z0-9]","").toUpperCase(java.util.Locale.ROOT);}
  private void valoReply(String id,org.json.JSONObject result){if(web==null)return;web.post(()->web.evaluateJavascript("window.dbzNativeValoResult&&window.dbzNativeValoResult("+org.json.JSONObject.quote(id)+","+org.json.JSONObject.quote(result.toString())+")",null));}
  private void lookupValo(String id,String input){
    pricingWork.execute(()->{org.json.JSONObject result=new org.json.JSONObject();try{
      String key=readValoSecret();if(key.isEmpty()){result.put("status","not_configured");valoReply(id,result);return;}
      org.json.JSONObject card=new org.json.JSONObject(input);String line=card.optString("line"),lang=card.optString("language"),condition=card.optString("condition"),finish=card.optString("finish");
      if(!"English".equals(lang)||!"Raw / Near Mint".equals(condition)||!("Masters".equals(line)||"Fusion World".equals(line))){result.put("status","unsupported");valoReply(id,result);return;}
      String game="Masters".equals(line)?"dragonball_super":"dragonball_fusion_world";
      String query="/data/v1/cards?game="+game+"&q="+URLEncoder.encode(card.optString("number"),"UTF-8")+"&language=en&page_size=100";
      org.json.JSONObject catalog=new org.json.JSONObject(valoGet(query,key));org.json.JSONArray items=catalog.optJSONArray("items");org.json.JSONArray matches=new org.json.JSONArray();
      for(int i=0;items!=null&&i<items.length();i++){org.json.JSONObject item=items.optJSONObject(i);if(item==null)continue;org.json.JSONObject edition=item.optJSONObject("edition");String itemName=item.optString("name_en",item.optString("name"));if(norm(item.optString("number")).equals(norm(card.optString("number")))&&edition!=null&&norm(edition.optString("name")).equals(norm(card.optString("set")))&&norm(itemName).equals(norm(card.optString("name")))&&"EN".equals(norm(item.optString("language"))))matches.put(item);}
      if(matches.length()!=1){result.put("status",matches.length()>1?"ambiguous":"no_match");valoReply(id,result);return;}
      org.json.JSONObject item=matches.getJSONObject(0);String pricesJson=valoGet("/data/v1/cards/"+item.getLong("card_id")+"/prices",key);org.json.JSONArray prices=new org.json.JSONObject(pricesJson).optJSONArray("prices");org.json.JSONArray sold=new org.json.JSONArray();
      for(int i=0;prices!=null&&i<prices.length();i++){org.json.JSONObject p=prices.optJSONObject(i);if(p==null||!"ebay".equals(p.optString("source"))||!"sold_median_raw".equals(p.optString("metric"))||!"available".equals(p.optString("status"))||!"EUR".equals(p.optString("currency"))||!"EN".equals(norm(p.optString("card_language")))||p.optDouble("amount",0)<=0)continue;String variant=p.optString("variant","default");if("Foil".equals(finish)?!variant.toLowerCase(java.util.Locale.ROOT).matches(".*(foil|holo).*"):!"default".equalsIgnoreCase(variant))continue;sold.put(p);}
      if(sold.length()!=1){result.put("status","no_sales");valoReply(id,result);return;}
      org.json.JSONObject p=sold.getJSONObject(0);if(p.optInt("sales_count",0)<1||p.optString("observed_at").isEmpty()){result.put("status","no_sales");valoReply(id,result);return;}
      result.put("status","matched").put("card_id",item.getLong("card_id")).put("amount",p.getDouble("amount")).put("currency",p.getString("currency")).put("observed_at",p.getString("observed_at")).put("sales_count",p.optInt("sales_count",0)).put("window_days",p.optInt("window_days",30)).put("collection",p.optString("collection","best_effort")).put("variant",p.optString("variant","default"));
    }catch(Exception e){try{result.put("status","unavailable").put("message",e.getMessage()==null?"Valo lookup failed":e.getMessage());}catch(Exception ignored){}}valoReply(id,result);});
  }
  public class NativeScanner {
    @android.webkit.JavascriptInterface public void savePricingBinder(String json){try{new org.json.JSONObject(json);PricingWorker.saveBinder(MainActivity.this,json);}catch(Exception ignored){}}
    @android.webkit.JavascriptInterface public String readBinderCollection(){return getSharedPreferences("dbz_vault_collection",MODE_PRIVATE).getString("binder_json","");}
    @android.webkit.JavascriptInterface public boolean saveBinderCollection(String json){try{org.json.JSONObject data=new org.json.JSONObject(json);if(!(data.opt("cards") instanceof org.json.JSONArray))return false;return getSharedPreferences("dbz_vault_collection",MODE_PRIVATE).edit().putString("binder_json",json).commit();}catch(Exception e){return false;}}
    @android.webkit.JavascriptInterface public String readPriceHistory(){return getSharedPreferences("dbz_vault_collection",MODE_PRIVATE).getString("price_history_json","");}
    @android.webkit.JavascriptInterface public boolean savePriceHistory(String json){try{org.json.JSONObject data=new org.json.JSONObject(json);if(data.optInt("version")!=2||!(data.opt("snapshots") instanceof org.json.JSONArray)||!(data.opt("cards") instanceof org.json.JSONObject))return false;return getSharedPreferences("dbz_vault_collection",MODE_PRIVATE).edit().putString("price_history_json",json).commit();}catch(Exception e){return false;}}
    @android.webkit.JavascriptInterface public String readVaultBackup(){java.io.File file=new java.io.File(getFilesDir(),"DBZ-Vault-Backup.json");if(!file.isFile())return "";try(java.io.FileInputStream in=new java.io.FileInputStream(file);java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){if(out.size()+n>75*1024*1024)return "";out.write(b,0,n);}return out.toString("UTF-8");}catch(Exception e){return "";}}
    @android.webkit.JavascriptInterface public boolean saveVaultBackup(String json){try{org.json.JSONObject data=new org.json.JSONObject(json);if(!"DBZ Vault".equals(data.optString("app"))||!(data.opt("cards") instanceof org.json.JSONArray)||json.length()>75*1024*1024)return false;java.io.File target=new java.io.File(getFilesDir(),"DBZ-Vault-Backup.json"),temp=new java.io.File(getFilesDir(),"DBZ-Vault-Backup.json.tmp");try(java.io.FileOutputStream out=new java.io.FileOutputStream(temp)){out.write(json.getBytes(java.nio.charset.StandardCharsets.UTF_8));out.getFD().sync();}try{java.nio.file.Files.move(temp.toPath(),target.toPath(),java.nio.file.StandardCopyOption.REPLACE_EXISTING,java.nio.file.StandardCopyOption.ATOMIC_MOVE);}catch(Exception e){if(target.exists()&&!target.delete()||!temp.renameTo(target))return false;}writeBackupToDownloads(json);return true;}catch(Exception e){return false;}}
    private void writeBackupToDownloads(String json){if(android.os.Build.VERSION.SDK_INT<29)return;try{android.content.ContentResolver resolver=getContentResolver();android.net.Uri collection=android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI,uri=null;String name="DBZ-Vault-Backup.json",path=android.os.Environment.DIRECTORY_DOWNLOADS+"/";try(android.database.Cursor cursor=resolver.query(collection,new String[]{android.provider.MediaStore.Downloads._ID},android.provider.MediaStore.Downloads.DISPLAY_NAME+"=? AND "+android.provider.MediaStore.Downloads.RELATIVE_PATH+"=?",new String[]{name,path},null)){if(cursor!=null&&cursor.moveToFirst())uri=android.content.ContentUris.withAppendedId(collection,cursor.getLong(0));}android.content.ContentValues values=new android.content.ContentValues();values.put(android.provider.MediaStore.Downloads.DISPLAY_NAME,name);values.put(android.provider.MediaStore.Downloads.MIME_TYPE,"application/json");values.put(android.provider.MediaStore.Downloads.RELATIVE_PATH,path);values.put(android.provider.MediaStore.Downloads.IS_PENDING,1);if(uri==null)uri=resolver.insert(collection,values);else resolver.update(uri,values,null,null);if(uri==null)return;try(java.io.OutputStream out=resolver.openOutputStream(uri,"wt")){if(out==null)return;out.write(json.getBytes(java.nio.charset.StandardCharsets.UTF_8));out.flush();}android.content.ContentValues ready=new android.content.ContentValues();ready.put(android.provider.MediaStore.Downloads.IS_PENDING,0);resolver.update(uri,ready,null,null);}catch(Exception ignored){}}
    @android.webkit.JavascriptInterface public String readPricingResults(){return PricingWorker.readResults(MainActivity.this);}
    @android.webkit.JavascriptInterface public boolean hasValoKey(){return !readValoSecret().isEmpty();}
    @android.webkit.JavascriptInterface public boolean saveValoKey(String key){return saveValoSecret(key);}
    @android.webkit.JavascriptInterface public void clearValoKey(){valoPrefs().edit().clear().apply();}
    @android.webkit.JavascriptInterface public void lookupValoCard(String id,String card){lookupValo(id,card);}

    @android.webkit.JavascriptInterface public void beginExport(String id,String name,String mime){work.execute(()->{try{if(exportId!=null)throw new Exception("Finish the current export first");exportId=id;exportName=name.replaceAll("[^A-Za-z0-9._-]","_");exportMime=mime.startsWith("text/csv")?"text/csv":mime.startsWith("application/json")?"application/json":"application/octet-stream";exportFile=java.io.File.createTempFile("vault-export-",".tmp",getCacheDir());exportStream=new java.io.FileOutputStream(exportFile);exportSize=0;}catch(Exception e){exportNotice("Export could not start: "+e.getMessage());}});}
    @android.webkit.JavascriptInterface public void writeExportChunk(String id,String chunk){work.execute(()->{try{if(!id.equals(exportId)||exportStream==null)return;byte[] bytes=android.util.Base64.decode(chunk,android.util.Base64.DEFAULT);exportSize+=bytes.length;if(exportSize>100L*1024*1024)throw new Exception("Backup exceeds 100 MB");exportStream.write(bytes);}catch(Exception e){clearExport();exportNotice("Export failed: "+e.getMessage());}});}
    @android.webkit.JavascriptInterface public void finishExport(String id){work.execute(()->{try{if(!id.equals(exportId)||exportStream==null)return;exportStream.close();exportStream=null;runOnUiThread(()->{try{startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(exportMime).putExtra(Intent.EXTRA_TITLE,exportName),EXPORT_REQ);}catch(Exception e){work.execute(()->clearExport());exportNotice("No file-saving app is available");}});}catch(Exception e){clearExport();exportNotice("Export failed");}});}

    @android.webkit.JavascriptInterface public void open(String mode,String codes){
      try {org.json.JSONArray a=new org.json.JSONArray(codes);java.util.Set<String> known=new java.util.HashSet<>();for(int i=0;i<a.length();i++)known.add(a.getString(i).toUpperCase(java.util.Locale.ROOT).replaceAll("[^A-Z0-9]",""));ScannerActivity.knownCodes=known;}catch(Exception ignored){}
      runOnUiThread(()->startActivityForResult(new Intent(MainActivity.this,ScannerActivity.class).putExtra("mode",mode),SCAN_REQ));
    }
    @android.webkit.JavascriptInterface public void recognize(String id,String data){
      work.execute(()->{try{byte[] bytes=android.util.Base64.decode(data.substring(data.indexOf(',')+1),android.util.Base64.DEFAULT);android.graphics.Bitmap bitmap=android.graphics.BitmapFactory.decodeByteArray(bytes,0,bytes.length);if(bitmap==null)throw new Exception("Invalid photo");
        reader.process(com.google.mlkit.vision.common.InputImage.fromBitmap(bitmap,0)).addOnSuccessListener(t->reply(id,t.getText(),null)).addOnFailureListener(e->reply(id,null,e.getMessage())).addOnCompleteListener(t->bitmap.recycle());
      }catch(Exception e){reply(id,null,e.getMessage());}});
    }
  }
  private void reply(String id,String text,String error){runOnUiThread(()->{if(web!=null)web.evaluateJavascript("window.dbzNativeOCRResult("+org.json.JSONObject.quote(id)+","+org.json.JSONObject.quote(text==null?"":text)+","+(error==null?"null":org.json.JSONObject.quote(error))+")",null);});}

  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    PricingWorker.schedule(this);
    // Resize the WebView itself: its padding does not move fixed HTML headers/nav.
    android.widget.FrameLayout root=new android.widget.FrameLayout(this);
    root.setBackgroundColor(android.graphics.Color.rgb(11,16,24));
    web=new WebView(this);
    root.addView(web,new android.widget.FrameLayout.LayoutParams(-1,-1));
    VaultInsets.apply(this,root,0);
    setContentView(root);
    root.requestApplyInsets();

    WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
    s.setAllowFileAccess(false); s.setAllowContentAccess(true); s.setMediaPlaybackRequiresUserGesture(false);
    web.addJavascriptInterface(new NativeScanner(),"DBZNative");
    web.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){
        Uri u=request.getUrl();if("https".equals(u.getScheme())&&"appassets.androidplatform.net".equals(u.getHost()))return false;
        if("https".equals(u.getScheme())||"http".equals(u.getScheme()))try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception ignored){}return true;
      }

      @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request){
        Uri uri=request.getUrl();
        if("appassets.androidplatform.net".equals(uri.getHost()) && uri.getPath()!=null && uri.getPath().startsWith("/assets/")) {
          String name=uri.getPath().substring("/assets/".length());
          if("catalog-art".equals(name)) {
            try{
              Uri source=Uri.parse(uri.getQueryParameter("url"));
              if(!"https".equals(source.getScheme())||!"over9001.com".equals(source.getHost())||source.getUserInfo()!=null||source.getPort()!=-1||source.getPath()==null||!source.getPath().startsWith("/cards/"))throw new java.io.IOException("Unsupported artwork source");
              java.net.HttpURLConnection connection=(java.net.HttpURLConnection)new java.net.URL(source.toString()).openConnection();connection.setInstanceFollowRedirects(false);connection.setConnectTimeout(7000);connection.setReadTimeout(7000);connection.setRequestProperty("User-Agent","DBZVault/0.5 personal-card-artwork");
              if(connection.getResponseCode()!=200)throw new java.io.IOException("Artwork unavailable");
              String mime=connection.getContentType();if(mime==null||!mime.startsWith("image/"))throw new java.io.IOException("Not an image");
              java.io.ByteArrayOutputStream bytes=new java.io.ByteArrayOutputStream();try(InputStream in=connection.getInputStream()){byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1){if(bytes.size()+n>5*1024*1024)throw new java.io.IOException("Artwork too large");bytes.write(buffer,0,n);}}finally{connection.disconnect();}
              return new WebResourceResponse(mime.split(";")[0],null,new java.io.ByteArrayInputStream(bytes.toByteArray()));
            }catch(Exception e){return new WebResourceResponse("text/plain","UTF-8",404,"Not found",java.util.Collections.emptyMap(),new java.io.ByteArrayInputStream(new byte[0]));}
          }
          if("native-scan.jpg".equals(name)) {
            try{java.io.File file=scanFile;if(file!=null)return new WebResourceResponse("image/jpeg",null,new java.io.FileInputStream(file));}catch(Exception ignored){}
            return new WebResourceResponse("text/plain","UTF-8",404,"Not found",java.util.Collections.emptyMap(),new java.io.ByteArrayInputStream(new byte[0]));
          }
          if (!java.util.Arrays.asList("index.html","manifest.webmanifest","market-prices.json","mna-reference.json","pricing-engine.js","website-pricing.js","price-history.js","pricing-dashboard.js","dashboard-v19.css","dashboard-v20.css","dashboard-v22.css").contains(name)) return null;
          try {
            InputStream in=getAssets().open(name);
            String mime=name.endsWith(".css")?"text/css":name.endsWith(".js")?"application/javascript":name.endsWith(".json")||name.endsWith(".webmanifest")?"application/json":"text/html";
            return new WebResourceResponse(mime,"UTF-8",in);
          }
          catch(Exception ignored) { return null; }
        }
        return super.shouldInterceptRequest(view,request);
      }
    });
    web.setWebChromeClient(new WebChromeClient(){
      @Override public void onPermissionRequest(PermissionRequest request){
        runOnUiThread(()->{
          boolean camera=false;
          for(String r:request.getResources()) if(PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) camera=true;
          if(!camera || !"appassets.androidplatform.net".equals(request.getOrigin().getHost())) {request.deny();return;}
          if(checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED) request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
          else { pendingCamera=request;requestPermissions(new String[]{Manifest.permission.CAMERA},CAMERA_REQ); }
        });
      }
      @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params){
        if(pendingFiles!=null) pendingFiles.onReceiveValue(null);
        pendingFiles=cb;
        try { startActivityForResult(params.createIntent(),FILE_REQ); return true; }
        catch(Exception e){pendingFiles=null;cb.onReceiveValue(null);return false;}
      }
    });
    web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
  }
  @Override public void onRequestPermissionsResult(int code,String[] permissions,int[] results){
    super.onRequestPermissionsResult(code,permissions,results);
    if(code==CAMERA_REQ && pendingCamera!=null){
      if(results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED) pendingCamera.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
      else pendingCamera.deny(); pendingCamera=null;
    }
  }
  @Override protected void onActivityResult(int req,int result,Intent data){
    super.onActivityResult(req,result,data);
    if(req==EXPORT_REQ){
      if(result==RESULT_OK&&data!=null&&data.getData()!=null){Uri target=data.getData();work.execute(()->{try{if(exportFile==null)throw new java.io.IOException("Export expired");try(InputStream in=new java.io.FileInputStream(exportFile);java.io.OutputStream out=getContentResolver().openOutputStream(target)){if(out==null)throw new java.io.IOException("Could not open destination");byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1)out.write(buffer,0,n);}exportNotice("Saved "+exportName);}catch(Exception e){exportNotice("Could not save file: "+e.getMessage());}finally{clearExport();}});}else{work.execute(()->clearExport());exportNotice("Export cancelled — no file saved");}
    }
    if(req==SCAN_REQ && result==RESULT_OK && data!=null){
      String photo=data.getStringExtra("photo"),text=data.getStringExtra("text");
      java.io.File previous=scanFile;scanFile=new java.io.File(photo);if(previous!=null&&!previous.equals(scanFile))previous.delete();
      if(web!=null)web.evaluateJavascript("window.dbzNativeScanResult("+org.json.JSONObject.quote("https://appassets.androidplatform.net/assets/native-scan.jpg?t="+System.nanoTime())+","+org.json.JSONObject.quote(text==null?"":text)+")",null);
    }
    if(req==FILE_REQ && pendingFiles!=null){pendingFiles.onReceiveValue(result==RESULT_OK?WebChromeClient.FileChooserParams.parseResult(result,data):null);pendingFiles=null;}
  }
  @Override protected void onPause(){
    if(web!=null)web.evaluateJavascript("window.dbzPauseCamera && window.dbzPauseCamera()",null);
    super.onPause();
  }
  @Override protected void onResume(){
    super.onResume();
    if(web!=null)web.evaluateJavascript("window.dbzResumeCamera && window.dbzResumeCamera(); window.dbzPricingResume && window.dbzPricingResume()",null);
  }
  @Override protected void onDestroy(){
    if(pendingCamera!=null){pendingCamera.deny();pendingCamera=null;}
    reader.close();work.execute(()->clearExport());work.shutdown();if(scanFile!=null)scanFile.delete();
    if(web!=null){web.destroy();web=null;}
    super.onDestroy();
  }
  @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
