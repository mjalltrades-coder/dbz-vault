package com.dbzvault.collector;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Bundle;
import android.util.Size;
import android.view.Gravity;
import android.view.MotionEvent;
import android.widget.*;
import androidx.activity.ComponentActivity;
import androidx.camera.core.*;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.io.File;
import java.nio.ByteBuffer;
import java.util.*;
import java.util.concurrent.*;

public class ScannerActivity extends ComponentActivity {
  static volatile Set<String> knownCodes=Collections.emptySet();
  private final TextRecognizer reader=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
  private final ExecutorService executor=Executors.newSingleThreadExecutor();
  private PreviewView preview; private TextView status; private ImageCapture capture;
  private ProcessCameraProvider provider; private Camera camera;
  private boolean taking=false,closed=false,torch=false; private String lastCode="",detectedCode=""; private int stable=0; private long lastRead=0;
  private static final class NumberCrop {final byte[] data;final int width,height;NumberCrop(byte[] data,int width,int height){this.data=data;this.width=width;this.height=height;}}
  @Override public void onCreate(Bundle state){
    super.onCreate(state);
    LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);root.setPadding(16,16,16,16);root.setBackgroundColor(Color.rgb(15,20,30));
    status=new TextView(this);status.setTextColor(Color.WHITE);status.setTextSize(17);status.setPadding(8,12,8,12);status.setGravity(Gravity.CENTER);
    status.setText("Centre the printed number in the box. Scanning automatically…");root.addView(status);
    FrameLayout cameraStage=new FrameLayout(this);root.addView(cameraStage,new LinearLayout.LayoutParams(-1,0,1));
    preview=new PreviewView(this);preview.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);preview.setScaleType(PreviewView.ScaleType.FIT_CENTER);cameraStage.addView(preview,new FrameLayout.LayoutParams(-1,-1));
    cameraStage.addView(new CardGuideView(this),new FrameLayout.LayoutParams(-1,-1));
    LinearLayout buttons=new LinearLayout(this);buttons.setGravity(Gravity.CENTER);buttons.setPadding(0,dp(9),0,dp(2));
    root.addView(buttons,new LinearLayout.LayoutParams(-1,-2));
    addButton(buttons,"Read now",true,()->takePhoto());
    addButton(buttons,"Gallery",false,()->gallery());
    addButton(buttons,"Light",false,()->{if(camera!=null&&camera.getCameraInfo().hasFlashUnit()){torch=!torch;camera.getCameraControl().enableTorch(torch);}});
    addButton(buttons,"Close",false,()->finish());setContentView(root);
    // Install scanner insets only after ComponentActivity has installed its view-tree owners.
    // The native camera has no HTML viewport, so leave insets available to CameraX children.
    root.setOnApplyWindowInsetsListener((view,insets)->{
      if(android.os.Build.VERSION.SDK_INT>=30){
        android.graphics.Insets bars=insets.getInsets(android.view.WindowInsets.Type.systemBars()|android.view.WindowInsets.Type.displayCutout());
        view.setPadding(16+bars.left,16+bars.top,16+bars.right,16+bars.bottom);
      }
      return insets;
    });
    root.requestApplyInsets();
    preview.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_UP&&camera!=null){MeteringPoint point=preview.getMeteringPointFactory().createPoint(e.getX(),e.getY());camera.getCameraControl().startFocusAndMetering(new FocusMeteringAction.Builder(point).setAutoCancelDuration(3,TimeUnit.SECONDS).build());v.performClick();}return true;});
    if("gallery".equals(getIntent().getStringExtra("mode"))){if(state==null)gallery();}
    else if(checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)startCamera();
    else requestPermissions(new String[]{Manifest.permission.CAMERA},10);
  }
  private int dp(float value){return Math.round(value*getResources().getDisplayMetrics().density);}
  private void addButton(LinearLayout row,String label,boolean primary,Runnable action){
    Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(12);b.setTextColor(primary?Color.rgb(37,27,14):Color.rgb(226,235,246));
    b.setTypeface(android.graphics.Typeface.create("sans-serif-medium",android.graphics.Typeface.NORMAL));b.setMinHeight(dp(48));b.setMinimumHeight(dp(48));b.setPadding(dp(3),0,dp(3),0);b.setElevation(dp(1));
    GradientDrawable shape=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,primary?new int[]{Color.rgb(255,213,130),Color.rgb(240,160,65)}:new int[]{Color.rgb(29,44,63),Color.rgb(21,33,49)});
    shape.setCornerRadius(dp(13));if(!primary)shape.setStroke(dp(1),Color.rgb(53,73,96));b.setBackground(shape);
    LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(50),1);lp.setMargins(dp(4),0,dp(4),0);row.addView(b,lp);b.setOnClickListener(v->action.run());
  }
  private void gallery(){startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE),11);}
  @Override public void onRequestPermissionsResult(int code,String[] p,int[] r){super.onRequestPermissionsResult(code,p,r);if(code==10&&r.length>0&&r[0]==PackageManager.PERMISSION_GRANTED)startCamera();else status.setText("Camera permission is needed. You can still scan using Gallery.");}
  @android.annotation.SuppressLint("MissingPermission")
  private void startCamera(){
    com.google.common.util.concurrent.ListenableFuture<ProcessCameraProvider> future=ProcessCameraProvider.getInstance(this);
    future.addListener(()->{try{if(closed)return;provider=future.get();Preview p=new Preview.Builder().build();p.setSurfaceProvider(preview.getSurfaceProvider());capture=new ImageCapture.Builder().setTargetResolution(new Size(1920,1440)).build();ImageAnalysis analysis=new ImageAnalysis.Builder().setTargetResolution(new Size(1920,1440)).setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build();analysis.setAnalyzer(executor,this::analyze);provider.unbindAll();camera=provider.bindToLifecycle(this,CameraSelector.DEFAULT_BACK_CAMERA,p,capture,analysis);}catch(Exception e){status.setText("Could not start camera. Use Gallery or reopen scanner. "+e.getMessage());}},ContextCompat.getMainExecutor(this));
  }
  @androidx.annotation.OptIn(markerClass=androidx.camera.core.ExperimentalGetImage.class)
  private void analyze(ImageProxy frame){
    if(taking||closed||frame.getImage()==null||System.currentTimeMillis()-lastRead<350){frame.close();return;}
    lastRead=System.currentTimeMillis();
    int rotation=frame.getImageInfo().getRotationDegrees();
    NumberCrop crop;
    try{crop=cropNumberBox(frame,rotation);}catch(Exception e){frame.close();return;}
    frame.close();
    reader.process(InputImage.fromByteArray(crop.data,crop.width,crop.height,rotation,InputImage.IMAGE_FORMAT_NV21)).addOnSuccessListener(result->{
      Set<String> matches=new HashSet<>();
      for(com.google.mlkit.vision.text.Text.TextBlock block:result.getTextBlocks())for(com.google.mlkit.vision.text.Text.Line line:block.getLines()){
        String candidate=cardCodeFromLine(line.getText());
        if(!candidate.isEmpty())matches.add(candidate);
      }
      String code=matches.size()==1?matches.iterator().next():"";
      if(!code.isEmpty()&&code.equals(lastCode))stable++;else{lastCode=code;stable=code.isEmpty()?0:1;}
      if(stable>=2&&!taking&&!closed){detectedCode=code;status.setText("Number found — capturing card…");takePhoto();}
      else if(matches.size()>1)status.setText("More than one code found. Centre just the printed number in the box.");
    }).addOnFailureListener(e->{lastCode="";stable=0;});
  }
  private String cardCodeFromLine(String text){
    String normalized=text.toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9]","");
    if(normalized.length()<4)return "";
    for(String known:knownCodes)if(known.length()>=4&&(normalized.equals(known)||normalized.contains(known)))return known;
    java.util.regex.Matcher matcher=java.util.regex.Pattern.compile("[A-Z]{1,5}[0-9]{1,3}(?:[A-Z]{1,5}[0-9]{0,4}|[0-9]{1,5})").matcher(normalized);
    if(matcher.find())return matcher.group();
    return normalized.length()<=18&&normalized.matches("(?=.*[A-Z])(?=.*[0-9])[A-Z0-9]+")?normalized:"";
  }
  private NumberCrop cropNumberBox(ImageProxy frame,int rotation){
    int sourceWidth=frame.getWidth(),sourceHeight=frame.getHeight();
    int orientedWidth=rotation%180==0?sourceWidth:sourceHeight;
    int orientedHeight=rotation%180==0?sourceHeight:sourceWidth;
    float viewWidth=Math.max(1,preview.getWidth()),viewHeight=Math.max(1,preview.getHeight());
    float scale=Math.min(viewWidth/orientedWidth,viewHeight/orientedHeight);
    float shownWidth=orientedWidth*scale,shownHeight=orientedHeight*scale;
    float offsetX=(viewWidth-shownWidth)/2f,offsetY=(viewHeight-shownHeight)/2f;
    int left=even(Math.round((viewWidth*CardGuideView.NUMBER_LEFT-offsetX)/scale));
    int top=even(Math.round((viewHeight*CardGuideView.NUMBER_TOP-offsetY)/scale));
    int right=even(Math.round((viewWidth*(CardGuideView.NUMBER_LEFT+CardGuideView.NUMBER_WIDTH)-offsetX)/scale));
    int bottom=even(Math.round((viewHeight*(CardGuideView.NUMBER_TOP+CardGuideView.NUMBER_HEIGHT)-offsetY)/scale));
    left=Math.max(0,Math.min(orientedWidth-2,left));top=Math.max(0,Math.min(orientedHeight-2,top));
    right=Math.max(left+2,Math.min(orientedWidth,right));bottom=Math.max(top+2,Math.min(orientedHeight,bottom));
    int width=right-left,height=bottom-top;
    android.graphics.Rect roi;
    switch(rotation){
      case 90: roi=new android.graphics.Rect(top,sourceHeight-left-width,top+height,sourceHeight-left);break;
      case 180: roi=new android.graphics.Rect(sourceWidth-left-width,sourceHeight-top-height,sourceWidth-left,sourceHeight-top);break;
      case 270: roi=new android.graphics.Rect(sourceWidth-top-height,left,sourceWidth-top,left+width);break;
      default: roi=new android.graphics.Rect(left,top,left+width,top+height);
    }
    roi.left=Math.max(0,even(roi.left));roi.top=Math.max(0,even(roi.top));
    roi.right=Math.min(sourceWidth,even(roi.right));roi.bottom=Math.min(sourceHeight,even(roi.bottom));
    int cropWidth=roi.width(),cropHeight=roi.height();
    if(cropWidth<2||cropHeight<2)throw new IllegalArgumentException("Number crop is too small");
    ImageProxy.PlaneProxy[] planes=frame.getPlanes();
    ByteBuffer y=planes[0].getBuffer().duplicate(),u=planes[1].getBuffer().duplicate(),v=planes[2].getBuffer().duplicate();
    int yBase=y.position(),uBase=u.position(),vBase=v.position();
    int yRow=planes[0].getRowStride(),yPixel=planes[0].getPixelStride();
    int uRow=planes[1].getRowStride(),uPixel=planes[1].getPixelStride();
    int vRow=planes[2].getRowStride(),vPixel=planes[2].getPixelStride();
    byte[] nv21=new byte[cropWidth*cropHeight*3/2];int out=0;
    for(int row=0;row<cropHeight;row++)for(int col=0;col<cropWidth;col++)nv21[out++]=y.get(yBase+(roi.top+row)*yRow+(roi.left+col)*yPixel);
    for(int row=0;row<cropHeight;row+=2)for(int col=0;col<cropWidth;col+=2){
      int chromaRow=(roi.top+row)/2,chromaCol=(roi.left+col)/2;
      nv21[out++]=v.get(vBase+chromaRow*vRow+chromaCol*vPixel);
      nv21[out++]=u.get(uBase+chromaRow*uRow+chromaCol*uPixel);
    }
    return new NumberCrop(nv21,cropWidth,cropHeight);
  }
  private int even(int value){return value&~1;}
  private void takePhoto(){if(taking||capture==null||closed)return;taking=true;status.setText("Reading the number inside the box…");File f=new File(getCacheDir(),"scan-"+System.nanoTime()+".jpg");capture.takePicture(new ImageCapture.OutputFileOptions.Builder(f).build(),ContextCompat.getMainExecutor(this),new ImageCapture.OnImageSavedCallback(){public void onImageSaved(ImageCapture.OutputFileResults r){readFile(f);}public void onError(ImageCaptureException e){taking=false;lastCode="";stable=0;status.setText("Capture failed. Centre the number in the box or choose Gallery.");}});}
  private void readFile(File f){
    executor.execute(()->{
      Bitmap crop=null;
      try{
        BitmapFactory.Options options=new BitmapFactory.Options();
        options.inJustDecodeBounds=true;BitmapFactory.decodeFile(f.getAbsolutePath(),options);
        int sample=1;while(Math.max(options.outWidth/sample,options.outHeight/sample)>3000)sample*=2;
        options.inJustDecodeBounds=false;options.inSampleSize=sample;
        Bitmap source=BitmapFactory.decodeFile(f.getAbsolutePath(),options);
        if(source==null)throw new IllegalArgumentException("Image could not be decoded");
        int orientation=new android.media.ExifInterface(f.getAbsolutePath()).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION,android.media.ExifInterface.ORIENTATION_NORMAL);
        float rotation=orientation==android.media.ExifInterface.ORIENTATION_ROTATE_90?90:orientation==android.media.ExifInterface.ORIENTATION_ROTATE_180?180:orientation==android.media.ExifInterface.ORIENTATION_ROTATE_270?270:0;
        if(rotation!=0){Matrix matrix=new Matrix();matrix.postRotate(rotation);Bitmap rotated=Bitmap.createBitmap(source,0,0,source.getWidth(),source.getHeight(),matrix,true);if(rotated!=source)source.recycle();source=rotated;}
        int left=Math.max(0,Math.round(source.getWidth()*CardGuideView.NUMBER_LEFT));
        int top=Math.max(0,Math.round(source.getHeight()*CardGuideView.NUMBER_TOP));
        int width=Math.min(source.getWidth()-left,Math.round(source.getWidth()*CardGuideView.NUMBER_WIDTH));
        int height=Math.min(source.getHeight()-top,Math.round(source.getHeight()*CardGuideView.NUMBER_HEIGHT));
        if(width<1||height<1)throw new IllegalArgumentException("Number crop is empty");
        crop=Bitmap.createBitmap(source,left,top,width,height);source.recycle();
      }catch(Exception e){runOnUiThread(()->{taking=false;if(!closed)status.setText("Could not prepare number crop. Try again or choose a smaller image.");});return;}
      Bitmap numberCrop=crop;
      runOnUiThread(()->{
        if(closed){numberCrop.recycle();return;}
        reader.process(InputImage.fromBitmap(numberCrop,0)).addOnSuccessListener(t->{if(closed)return;String text=t.getText();if(!detectedCode.isEmpty()&&!text.contains(detectedCode))text=text+"\n"+detectedCode;setResult(RESULT_OK,new Intent().putExtra("photo",f.getAbsolutePath()).putExtra("text",text));finish();}).addOnFailureListener(e->{taking=false;status.setText("Could not read the number. Centre it in the box and try again.");}).addOnCompleteListener(t->numberCrop.recycle());
      });
    });
  }
  @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(req==11){if(result==RESULT_OK&&data!=null&&data.getData()!=null){taking=true;status.setText("Reading gallery image…");executor.execute(()->{try{File f=new File(getCacheDir(),"gallery-"+System.nanoTime()+".jpg");try(java.io.InputStream in=getContentResolver().openInputStream(data.getData());java.io.OutputStream out=new java.io.FileOutputStream(f)){byte[] b=new byte[8192];int n;long total=0;while((n=in.read(b))!=-1){total+=n;if(total>40*1024*1024)throw new java.io.IOException("Image too large");out.write(b,0,n);}}runOnUiThread(()->readFile(f));}catch(Exception e){runOnUiThread(()->{taking=false;status.setText("Could not open photo. Choose a smaller JPG or PNG.");});}});}else if("gallery".equals(getIntent().getStringExtra("mode")))finish();}}
  @Override protected void onDestroy(){closed=true;if(provider!=null)provider.unbindAll();executor.shutdown();reader.close();super.onDestroy();}
}
