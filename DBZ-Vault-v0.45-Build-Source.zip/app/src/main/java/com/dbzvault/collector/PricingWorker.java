package com.dbzvault.collector;

import android.content.Context;
import android.util.AtomicFile;
import androidx.annotation.NonNull;
import androidx.work.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.concurrent.TimeUnit;

/** Monthly binder checks use only our cached server feed, never client-side TCGCSV scraping. */
public class PricingWorker extends Worker {
  private static final long MONTH=TimeUnit.DAYS.toMillis(30);
  private static final String FEED="https://raw.githubusercontent.com/mjalltrades-coder/dbz-vault/price-data/prices.json";
  public PricingWorker(@NonNull Context context,@NonNull WorkerParameters params){super(context,params);}
  public static void schedule(Context c){
    PeriodicWorkRequest job=new PeriodicWorkRequest.Builder(PricingWorker.class,1,TimeUnit.DAYS)
      .setInitialDelay(1,TimeUnit.DAYS).setConstraints(new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
      .setBackoffCriteria(BackoffPolicy.EXPONENTIAL,30,TimeUnit.MINUTES).build();
    WorkManager.getInstance(c).enqueueUniquePeriodicWork("dbz-vault-monthly-pricing-v1",ExistingPeriodicWorkPolicy.KEEP,job);
  }
  private static AtomicFile file(Context c,String name){return new AtomicFile(new File(c.getFilesDir(),name));}
  private static synchronized String read(Context c,String name){try{return new String(file(c,name).readFully(),StandardCharsets.UTF_8);}catch(Exception e){return "{}";}}
  private static synchronized void write(Context c,String name,String json)throws IOException{
    AtomicFile f=file(c,name);FileOutputStream out=null;try{out=f.startWrite();out.write(json.getBytes(StandardCharsets.UTF_8));f.finishWrite(out);}catch(IOException e){if(out!=null)f.failWrite(out);throw e;}
  }
  public static void saveBinder(Context c,String json)throws IOException{write(c,"pricing-binder.json",json);}
  public static String readResults(Context c){return read(c,"pricing-results.json");}
  private static long millis(String value){try{return Instant.parse(value).toEpochMilli();}catch(Exception e){return 0;}}
  private static String norm(String s){return s.replaceAll("[^A-Za-z0-9]", "").toUpperCase(java.util.Locale.ROOT);}
  private static boolean same(JSONObject a,String ak,JSONObject b,String bk){return norm(a.optString(ak)).equals(norm(b.optString(bk)));}
  private JSONObject download()throws Exception{
    HttpURLConnection c=(HttpURLConnection)new URL(FEED).openConnection();c.setInstanceFollowRedirects(false);c.setConnectTimeout(15000);c.setReadTimeout(20000);c.setRequestProperty("User-Agent","DBZVault/0.12 monthly-pricing");
    try{if(c.getResponseCode()!=200)throw new IOException("Price feed unavailable");ByteArrayOutputStream out=new ByteArrayOutputStream();try(InputStream in=c.getInputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){if(out.size()+n>24*1024*1024)throw new IOException("Price feed too large");out.write(b,0,n);}}JSONObject feed=new JSONObject(out.toString("UTF-8"));double rate=feed.optDouble("usdToAud",0);if(feed.optInt("schema")!=1||!"AUD".equals(feed.optString("currency"))||rate<=0||!Double.isFinite(rate)||feed.optJSONObject("quotes")==null||millis(feed.optString("updated"))<=0)throw new IOException("Invalid price feed");return feed;}finally{c.disconnect();}
  }
  @NonNull @Override public Result doWork(){
    Context c=getApplicationContext();
    try{
      JSONObject binder=new JSONObject(read(c,"pricing-binder.json"));JSONArray cards=binder.optJSONArray("cards");if(cards==null||cards.length()==0)return Result.success();
      JSONObject previous=new JSONObject(readResults(c)),monthly=binder.optJSONObject("monthly");long last=Math.max(millis(previous.optString("completed_at")),monthly==null?0:millis(monthly.optString("completed_at")));if(System.currentTimeMillis()-last<MONTH)return Result.success();
      JSONObject feed=download(),quotes=feed.getJSONObject("quotes");JSONArray results=new JSONArray();String now=Instant.now().toString();
      for(int i=0;i<cards.length();i++){
        if(isStopped())return Result.retry();JSONObject item=cards.getJSONObject(i),card=item.getJSONObject("card"),result=new JSONObject().put("key",item.getString("key")).put("fingerprint",item.getString("fingerprint"));
        JSONObject q=quotes.optJSONObject(card.optString("card_number")+"@@"+item.optString("finish"));
        if(q!=null&&"English".equals(card.optString("language"))&&"English".equals(q.optString("language"))&&"Raw / Near Mint".equals(item.optString("condition"))&&"Base".equals(card.optString("variant","Base"))&&card.optString("line").equals(q.optString("line"))&&item.optString("finish").equals(q.optString("finish"))&&same(card,"name",q,"name")&&same(card,"set_name",q,"set")){
          double usd=q.optDouble("usd",0),aud=q.optDouble("aud",0),rate=feed.getDouble("usdToAud");
          if(Double.isFinite(usd)&&Double.isFinite(aud)&&usd>0&&aud>0&&q.optLong("productId",0)>0&&Math.abs(aud-Math.round(usd*rate*100)/100.0)<.011){
            JSONObject price=new JSONObject().put("price",aud).put("source","tcgplayer_market").put("price_type","recent_sales_aggregate").put("original_currency","USD").put("original_price",usd).put("exchange_rate_to_aud",rate).put("fx_source",feed.optString("fxSource","Frankfurter")).put("fx_date",feed.getString("fxDate")).put("source_url","https://www.tcgplayer.com/product/"+q.getLong("productId")).put("observed_at",feed.getString("updated")).put("checked",now).put("fingerprint",item.getString("fingerprint")).put("auto",true);
            result.put("quote",price);
          }
        }
        results.put(result);
      }
      // Native storage is separate from WebView collection data; merges happen only after exact identity checks.
      write(c,"pricing-results.json",new JSONObject().put("feed",feed).put("cards",results).put("checked_at",now).put("native_feed_checked_at",now).toString());return Result.success();
    }catch(Exception e){return Result.retry();}
  }
}
