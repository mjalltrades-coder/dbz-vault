package com.dbzvault.collector;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Shows where to place the printed number; capture and OCR use this same region. */
public final class CardGuideView extends View {
  static final float NUMBER_LEFT=.185f;
  static final float NUMBER_TOP=.4475f;
  static final float NUMBER_WIDTH=.63f;
  static final float NUMBER_HEIGHT=.105f;

  private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
  private final RectF frame=new RectF();
  private final float density;

  public CardGuideView(Context context){
    super(context);
    density=getResources().getDisplayMetrics().density;
    setClickable(false);
    setFocusable(false);
    setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
  }

  @Override protected void onSizeChanged(int w,int h,int oldw,int oldh){
    super.onSizeChanged(w,h,oldw,oldh);
    frame.set(w*NUMBER_LEFT,h*NUMBER_TOP,w*(NUMBER_LEFT+NUMBER_WIDTH),h*(NUMBER_TOP+NUMBER_HEIGHT));
  }

  RectF guideBounds(){return new RectF(frame);}

  @Override protected void onDraw(Canvas canvas){
    super.onDraw(canvas);
    if(frame.width()<=0)return;

    // Lightly darken the area around the number so the small target stands out.
    paint.setStyle(Paint.Style.FILL);
    paint.setColor(Color.argb(105,0,0,0));
    canvas.drawRect(0,0,getWidth(),frame.top,paint);
    canvas.drawRect(0,frame.bottom,getWidth(),getHeight(),paint);
    canvas.drawRect(0,frame.top,frame.left,frame.bottom,paint);
    canvas.drawRect(frame.right,frame.top,getWidth(),frame.bottom,paint);

    paint.setStyle(Paint.Style.STROKE);
    paint.setStrokeJoin(Paint.Join.ROUND);
    paint.setColor(Color.WHITE);
    paint.setStrokeWidth(2*density);
    canvas.drawRoundRect(frame,5*density,5*density,paint);
    paint.setColor(Color.rgb(255,190,78));
    paint.setStrokeWidth(3*density);
    canvas.drawRoundRect(frame,5*density,5*density,paint);

    float corner=Math.min(18*density,frame.width()/10);
    for(int x=0;x<2;x++)for(int y=0;y<2;y++){
      float px=x==0?frame.left:frame.right,py=y==0?frame.top:frame.bottom;
      canvas.drawLine(px,py,px+(x==0?corner:-corner),py,paint);
      canvas.drawLine(px,py,px,py+(y==0?corner:-corner),paint);
    }

    float labelWidth=105*density,labelHeight=22*density;
    float labelLeft=Math.max(0,Math.min(getWidth()-labelWidth,frame.centerX()-labelWidth/2));
    float labelTop=Math.max(0,frame.top-labelHeight-5*density);
    paint.setStyle(Paint.Style.FILL);
    paint.setColor(Color.rgb(255,190,78));
    canvas.drawRoundRect(labelLeft,labelTop,labelLeft+labelWidth,labelTop+labelHeight,6*density,6*density,paint);
    paint.setColor(Color.rgb(24,35,49));
    paint.setTextAlign(Paint.Align.CENTER);
    paint.setTypeface(android.graphics.Typeface.create("sans-serif",android.graphics.Typeface.BOLD));
    paint.setTextSize(10*density);
    canvas.drawText("CARD NUMBER",labelLeft+labelWidth/2,labelTop+15*density,paint);
  }
}
