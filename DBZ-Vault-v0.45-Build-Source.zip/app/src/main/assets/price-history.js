/* Auditable portfolio history. Prices are observations, never invented backfill. */
(function(root){
'use strict';
const labels={sold:'Sold-based values',market:'Market estimates',fallback:'Normal-price fallbacks',asking:'For-sale asking prices',manual:'Manual / other values',unpriced:'Unpriced'};
function category(q){if(!q||!Number.isFinite(+q.price)||+q.price<=0)return 'unpriced';if(q.normal_price_fallback)return 'fallback';if(q.source==='ebay_sold')return 'sold';if(q.source==='tcgplayer_market')return 'market';if(['mna_cardz_guide','ebay_asking'].includes(q.source))return 'asking';return 'manual';}
function summarize(items){const groups=Object.fromEntries(Object.keys(labels).map(k=>[k,{value:0,copies:0,entries:0}]));let total=0,copies=0;for(const x of Object.values(items)){const g=groups[x.kind];g.value+=x.qty*(x.price||0);g.copies+=x.qty;g.entries++;total+=x.qty*(x.price||0);copies+=x.qty;}return {groups,total,copies};}
function compare(before,after){const d={price:0,quantity:0,coverage:0,revaluation:0,total:0};for(const k of new Set([...Object.keys(before),...Object.keys(after)])){const a=before[k],b=after[k];const ap=a?.price||0,bp=b?.price||0,aq=a?.qty||0,bq=b?.qty||0;d.total+=bp*bq-ap*aq;if(!a){d.quantity+=bp*bq;continue;}if(!b){d.quantity-=ap*aq;continue;}const common=Math.min(aq,bq);d.quantity+=(bq>aq?(bq-aq)*bp:(bq-aq)*ap);if(!ap||!bp)d.coverage+=(bp-ap)*common;else if(a.source!==b.source||a.kind!==b.kind||a.identity!==b.identity||b.kind==='manual'||a.confirmed!==b.confirmed)d.revaluation+=(bp-ap)*common;else d.price+=(bp-ap)*common;}return d;}
function priceChanges(a,b){return !a||a.price!==b.price||a.source!==b.source||a.kind!==b.kind||a.identity!==b.identity||a.confirmed!==b.confirmed;}
const api={labels,category,summarize,compare,priceChanges};if(typeof module!=='undefined')module.exports=api;root.DBZHistoryMath=api;
})(typeof window==='undefined'?globalThis:window);
