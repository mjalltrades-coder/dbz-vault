/* Pure pricing rules shared by the Android WebView and regression tests. */
(function(root){
'use strict';
const ranks={ebay_sold:1,ebay_sold_aggregate:1,tcgplayer_market:2,mna_cardz_guide:3,ebay_asking:4,manual:0};
const norm=s=>String(s||'').normalize('NFKC').replace(/[^a-z0-9]/gi,'').toUpperCase();
const fingerprint=(c,f,condition)=>JSON.stringify([c.card_number,c.line,c.set_name,c.language,c.variant||'Base',f,condition]);
const validTime=t=>typeof t==='string'&&Number.isFinite(Date.parse(t))&&Date.parse(t)<=Date.now()+86400000;
function valid(q){return !!(q&&Object.hasOwn(ranks,q.source)&&Number.isFinite(q.original_price)&&q.original_price>0&&Number.isFinite(q.exchange_rate_to_aud)&&q.exchange_rate_to_aud>0&&Number.isFinite(q.price)&&q.price>0&&Math.abs(q.price-Math.round(q.original_price*q.exchange_rate_to_aud*100)/100)<.011&&/^[A-Z]{3}$/.test(q.original_currency)&&validTime(q.observed_at)&&validTime(q.checked)&&validTime(q.fx_date)&&q.fx_source&&q.fingerprint&&safeURL(q.source_url,q.source));}
function safeURL(url,source){try{const u=new URL(url);const h=u.hostname.replace(/^www\./,'');const ebayPath=u.pathname.startsWith('/itm/')||u.pathname.startsWith('/sch/i.html')&&u.searchParams.get('LH_Sold')==='1'&&u.searchParams.get('LH_Complete')==='1';return u.protocol==='https:'&&!u.username&&!u.password&&((source==='ebay_sold'||source==='ebay_asking'||source==='ebay_sold_aggregate')?ebayPath:source==='tcgplayer_market'?u.pathname.startsWith('/product/'):source==='mna_cardz_guide'?u.pathname.startsWith('/products/'):false)&&({ebay_sold:['ebay.com.au','ebay.com','ebay.co.uk','ebay.ca','ebay.de','ebay.fr','ebay.it','ebay.es','ebay.ie','ebay.nl','ebay.at','ebay.ch','ebay.be','ebay.pl','ebay.com.hk','ebay.com.sg'],tcgplayer_market:['tcgplayer.com'],mna_cardz_guide:['mnacardz.com']}[source==='ebay_asking'||source==='ebay_sold_aggregate'?'ebay_sold':source]||[]).includes(h);}catch(e){return false;}}
function choose(old,candidate){
 if(!valid(candidate))return {status:'no_match',value:old};
 if(old&&(old.user_confirmed||old.source==='manual'||(ranks[old.source]??0)<ranks[candidate.source]))return {status:'review',value:old,suggestion:candidate};
 if(old&&old.source==='tcgplayer_market'&&!old.normal_price_fallback&&candidate.normal_price_fallback)return {status:'review',value:old,suggestion:candidate};
 if(old&&validTime(old.observed_at)&&Date.parse(candidate.observed_at)<Date.parse(old.observed_at))return {status:'older',value:old};
 return {status:'updated',value:candidate};
}
function tcg(c,f,condition,feed,checked){
 if(c.language!=='English'||condition!=='Raw / Near Mint'||(c.variant||'Base')!=='Base'||!feed)return null;
 const cleanName=s=>norm(String(s||'').replace(/(?:\s*\([^()]*\)\s*)+$/,''));
 const products=tcgChoices(c,feed).filter(q=>cleanName(q.name)===cleanName(c.name));
 let matches=f==='Foil'?products.filter(q=>['Foil','Holofoil','Parallel Foil'].includes(q.sourceFinish)):products.filter(q=>q.sourceFinish==='Normal'),fallback=false;
 if(matches.length>1)return null;
 if(!matches.length&&f==='Foil'){matches=products.filter(q=>q.sourceFinish==='Normal');fallback=true;}
 if(matches.length!==1)return null;
 const q=matches[0];
 const r={price:q.aud,source:'tcgplayer_market',price_type:'recent_sales_aggregate',original_currency:'USD',original_price:q.usd,exchange_rate_to_aud:feed.usdToAud,fx_source:feed.fxSource||'Frankfurter',fx_date:feed.fxDate,source_url:q.source_url||'https://www.tcgplayer.com/product/'+q.productId,observed_at:feed.updated,checked,fingerprint:fingerprint(c,f,condition),condition_basis:'Product-level market aggregate; condition-specific data unavailable',normal_price_fallback:fallback,source_finish:q.sourceFinish,auto:true};
 return valid(r)?r:null;
}
function mna(c,f,condition,data,mapping,checked){
 if(!mapping||mapping.source==='tcgplayer_market'||mapping.fingerprint!==fingerprint(c,f,condition))return null;
 const q=data?.records?.find(q=>q.source_record_id===mapping.product_id);
 if(!q||!q.card_code||norm(q.card_code)!==norm(c.printed_number||c.card_number)||q.variant_count!==1)return null;
 const r={price:q.guide_price_aud,source:'mna_cardz_guide',price_type:'retailer_asking_price_guide',original_currency:'USD',original_price:q.source_price_usd,exchange_rate_to_aud:q.fx_usd_to_aud,fx_date:q.fx_rate_as_of,fx_source:'Supplied MNA snapshot conversion',source_url:q.source_url,observed_at:q.snapshot_date,checked,fingerprint:mapping.fingerprint,source_record_id:q.source_record_id,auto:true,snapshot:true};return valid(r)?r:null;
}
function mnaAuto(c,f,condition,data,checked){
 if(!['Normal','Foil'].includes(f)||condition!=='Raw / Near Mint'||(c.variant||'Base')!=='Base'||!data?.records)return null;
 const lines={'Super Dragon Ball Heroes':'Dragonball Heroes','Masters':'Dragonball Super','Fusion World':'Dragonball Fusion World','Dragon Ball Super Divers':'Dragon Ball Super Divers'};
 const line=lines[c.line],code=norm(c.printed_number||c.card_number),printedSet=norm(String(c.printed_number||c.card_number).split('-')[0]);
 const setKey=s=>norm(s).replace(/^([A-Z]+)0+([0-9]+)$/,'$1$2');
 const sets=new Set([setKey(c.set_code),setKey(printedSet)]);
 if(!line||!code||![...sets].some(Boolean)||!c.name)return null;
 const cleanName=s=>norm(String(s||'').replace(/^(?:(?:C|UC|R|SR|SPR|SCR|UR|AR|GDR|DR|HR|GR|BR|RR|L|PR|PROMO|SEC|CP)(?:★)?\s*)+/i,'').replace(/(?:\s*(?:C|UC|R|SR|SPR|SCR|UR|AR|GDR|DR|HR|GR|BR|RR|L|PR|PROMO|SEC|CP)(?:★)?)+\s*$/i,''));
 // A retailer's current stock flag does not invalidate a saved listing price.
 // Keep the automatic match strict on code, set, product line and name, and only
 // accept one unambiguous single-variant listing.
 const name=cleanName(c.name),rows=data.records.filter(q=>q&&q.product_line===line&&q.card_code&&norm(q.card_code)===code&&sets.has(setKey(q.set_code))&&q.variant_count===1&&cleanName(q.name)===name);
 if(rows.length!==1)return null;
 const q=rows[0],mapping={fingerprint:fingerprint(c,f,condition),product_id:q.source_record_id};
 const r={price:q.guide_price_aud,source:'mna_cardz_guide',price_type:'retailer_asking_price_guide',original_currency:'USD',original_price:q.source_price_usd,exchange_rate_to_aud:q.fx_usd_to_aud,fx_date:q.fx_rate_as_of,fx_source:'Supplied MNA snapshot conversion',source_url:q.source_url,observed_at:q.snapshot_date,checked,fingerprint:mapping.fingerprint,source_record_id:q.source_record_id,source_finish:'Normal',normal_price_fallback:f==='Foil',mna_stock_available:q.is_in_stock_at_snapshot===true,condition_basis:f==='Foil'?'MNA has no exact foil quote; displayed normal retailer guide as fallback':q.is_in_stock_at_snapshot===true?'MNA retailer asking-price guide; listing was in stock at snapshot':'MNA retailer asking-price guide; listing was out of stock at snapshot',auto:true,snapshot:true};
 return valid(r)?r:null;
}
function tcgChoices(c,feed){
 if(c.language!=='English')return [];
 let rows=feed?.candidates?.[c.card_number]||[];
 // Older server feeds can still update a pinned original product, but never guess an alternate printing.
 if((feed?.matcherVersion||1)<4){rows=['Normal','Foil'].map(f=>feed?.quotes?.[c.card_number+'@@'+f]).filter(Boolean).map(q=>({...q,card_number:c.card_number,sourceFinish:q.sourceFinish||q.finish,source_url:'https://www.tcgplayer.com/product/'+q.productId}));rows=rows.filter((q,i)=>rows.findIndex(x=>x.productId===q.productId&&x.sourceFinish===q.sourceFinish)===i);}
 return rows.filter(q=>q.card_number===c.card_number&&q.line===c.line&&q.language===c.language&&norm(q.set)===norm(c.set_name)&&Number.isSafeInteger(q.productId)&&q.productId>0&&['Normal','Foil','Holofoil','Parallel Foil'].includes(q.sourceFinish)&&Number.isFinite(q.usd)&&q.usd>0&&Number.isFinite(q.aud)&&q.aud>0&&Math.abs(q.aud-Math.round(q.usd*feed.usdToAud*100)/100)<.011&&safeURL(q.source_url,'tcgplayer_market'));
}
function selectedTcg(c,f,condition,feed,mapping,checked){
 if(!mapping||mapping.source!=='tcgplayer_market'||mapping.confirmed!==true||mapping.fingerprint!==fingerprint(c,f,condition)||condition!=='Raw / Near Mint')return null;
 const product=tcgChoices(c,feed).filter(q=>q.productId===mapping.product_id);
 let rows=product.filter(q=>q.sourceFinish===mapping.source_finish);
 if(f==='Foil'&&mapping.source_finish==='Normal'){const foil=product.filter(q=>['Foil','Holofoil'].includes(q.sourceFinish));if(foil.length===1)rows=foil;}
 if(!rows.length&&f==='Foil')rows=product.filter(q=>q.sourceFinish==='Normal');
 if(rows.length!==1)return null;const q=rows[0];
 const r={price:q.aud,source:'tcgplayer_market',price_type:'recent_sales_aggregate',original_currency:'USD',original_price:q.usd,exchange_rate_to_aud:feed.usdToAud,fx_source:feed.fxSource||'Frankfurter',fx_date:feed.fxDate,source_url:q.source_url,observed_at:feed.updated,checked,fingerprint:fingerprint(c,f,condition),condition_basis:'User confirmed product/printing; product-level market aggregate, not condition-specific',product_id:q.productId,product_name:q.name,source_finish:q.sourceFinish,normal_price_fallback:f==='Foil'&&q.sourceFinish==='Normal',identity_confirmed:true,auto:true};
 return valid(r)?r:null;
}
function due(last,now=Date.now()){return !Number.isFinite(Date.parse(last))||now-Date.parse(last)>=30*86400000;}
root.DBZPricing={ranks,norm,fingerprint,valid,safeURL,choose,tcg,mna,mnaAuto,tcgChoices,selectedTcg,due};
if(typeof module!=='undefined')module.exports=root.DBZPricing;
})(typeof window!=='undefined'?window:globalThis);
