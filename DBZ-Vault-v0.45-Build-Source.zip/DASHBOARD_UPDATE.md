# Version 0.21 — more visible camera guide

Strengthened the native camera guide to a full thick orange card-shaped border, amber label “PLACE CARD HERE,” dark surround, and clear instruction. Tap to focus still works. Build and Android lint passed. The scanner camera preview itself could not be checked on a physical device here.

Three-year history research: current alternate public datasets found only point-in-time or shorter-window data, not a verified three-year Dragon Ball card series. TCGCSV documents daily historical archives beginning 2024-02-08, short of three years as of October 2026; archive requests from this environment return 403. PriceCharting documents that historic prices are not available through its API. Thus no fabricated backfill was added.

# Version 0.20 — scanner alignment guide

Added a 63:88 card rectangle with white outline, amber corners and a dimmed surround to the native camera. Overlay does not intercept focus taps or crop OCR/capture input. It scales to preview bounds on rotation. Includes the version 0.19 home redesign; visible badge now v0.20.

APK and instrumentation test APK compiled; Android lint and browser dashboard/recognition checks passed. Camera overlay assertions were added to the instrumented test but were not executed on a device in this session.

Historical market backfill remains incomplete: TCGCSV documents daily archives starting 2024-02-08, but tested archive URLs returned HTTP 403 in this environment. No historical market prices were imported or fabricated.

# Version 0.19 visual update

Home now displays Price dashboard and v0.19, a blue collection-value panel, prominent sold/estimate/unpriced summary and first-screen refresh and breakdown buttons. Prior history and storage remain unchanged. Mobile UI checks and the APK build passed.

# DBZ Vault 0.18 — pricing dashboard and history

Built from the saved Version Pricing source, with the pricing JavaScript recovered from the latest For Sale Prices APK (0.17). Existing scanner/native code retained. Application ID, storage origin and signing certificate match the prior APK; versionCode increased to 18.

Dashboard separates sold-based, market, normal-price fallback, asking, manual and unpriced values. All totals use unit price × quantity. Recorded changes are reconciled into same-source price changes, quantity changes, pricing coverage and manual/source/version changes. These are valuation changes, not investment returns. Per-card history records unit prices and provenance independently of quantity. The new history starts with this update; no earlier per-card prices are fabricated. Up to 365 portfolio observations and 365 observations per card are retained. Backup/restore includes new history and legacy totals.

Validation: Android assembleDebug, testDebugUnitTest and lintDebug; signature match with 0.17; recognition, market, portfolio, pricing engine and Python pricing tests; browser UI tests for remembered versions, manual-price protection, offline retention, history reconciliation, mobile layout and history restore. No physical phone or camera test was performed in this session.

Build with Java 17, Gradle 8.9 and Android SDK/build tools 35, using `gradle assembleDebug`. Existing development signing key is included to preserve update compatibility. Do not generate a new key when building an update.

The GitHub connector returned 404 and no accessible repositories during this session. These changes were not pushed to GitHub. The included prior GitHub workflow still expects the repository's source ZIP layout and existing historical signing-key commit.

Online pricing limitations remain: eBay prices require manual verification; the TCGplayer feed is automatic when available; MNA is the bundled dated snapshot. Asking prices and Normal-for-Foil fallbacks remain explicitly labelled.
