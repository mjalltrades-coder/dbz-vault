DBZ Vault Android 0.11 — simple eBay searches

CameraX scanner, gallery scanning and seven-star icon are retained.
Automatic pricing: exact English Masters, Fusion World and Panini matches from TCGplayer Market via TCGCSV, converted from USD to AUD using Frankfurter reference rates. The provider snapshot is updated daily by GitHub Actions. The app checks its own hosted feed at most daily and retains the last working prices offline.

Manual vintage prices remain unchanged and take priority. Unsupported cards, alternate artwork without an exact mapping, graded/played/damaged holdings and Japanese cards are not assigned English base-card prices. Market references are not guaranteed resale prices. Source dates, FX dates and matched product links are shown in card details.

The optional catalogue audit and artwork-index panels are hidden; the native camera scanner does not depend on them. Native Android file saving is available for collection backup and CSV exports. Status-bar insets prevent the header from overlapping phone indicators.

Build source: DBZ-Vault-GitHub-APK-Build-Ready.zip. Package com.dbzvault.collector.nativescan, version code 11. Uses the same development signing key as versions 0.4 and 0.5, allowing installation as an update without removing collection data.

Validation: JavaScript syntax and scanner tests; price-matching and manual-override tests; Android lint and APK compilation. Physical-device verification is still required for updated Android UI integrations.

Data sources: https://tcgcsv.com/ and https://frankfurter.dev/

0.33: after a card is saved by scanning, the app refreshes the TCGplayer market feed and checks exact card, set and finish matches. If no TCGplayer match is available, it checks the saved MNA Cardz reference snapshot. The scan status shows the source lookup and outcome. eBay sold results remain a manual review link because the app has no connected eBay sold-data feed; it does not invent a sold price. New cards added through the card editor also start the same lookup.
GitHub Actions restores the existing PUBLIC DEVELOPMENT-ONLY signing key from repository history. The source upload excludes signing-key files. This is not a production credential.

Portfolio layout: dark dashboard with large AUD value, most-valuable cards, recent additions, cleaner card details and central scanner navigation. Portfolio history records the priced portion of the collection on days the app is opened. New history begins when priced cards are added; past values and gains are never fabricated. Vintage manual pricing is retained.

0.7 changes: recognise combined front/back leader names and Parallel Foil market subtypes, preserve exact set and artwork checks. Existing binder entries receive matching prices without re-scanning. New matcher versions rebuild the feed even when the source date is unchanged. Updated bundled prices supersede old cached matching data. Manual values keep priority. WebView now sits inside an inset-aware native container, keeping fixed headers, bottom navigation, card dialogs and scanner controls clear of status/navigation bars and keyboard.

Automatic adding: a unique exact printed-number match of 100 saves one card immediately, with Undo. New scans increment quantity; retries of the same photo do not. Ambiguous codes and corrected/fuzzy readings remain suggestions. New entries keep finish Not set until Normal/Foil is chosen; this moves the entry instead of adding a second card. No reflective finish is inferred from glare. Reviewed original BT2-001 and BT1-031 standard holographic products can use their exact TCGplayer Normal-labelled product prices, explicitly disclosed in source details; no general cross-finish fallback is used.

0.8: native scanner uses its original window startup path, with scanner-specific safe-area padding installed after setContentView. The WebView retains its separate safe-area container. Android instrumentation checks open/reopen the camera and open it through the scan tab and JavaScript bridge.

0.9: replace the expanded price research queue with Update card prices. A user-initiated update bypasses the automatic daily check interval and retrieves the latest hosted snapshot, automatically revaluing matching binder entries and portfolio totals. Shows a compact result rather than individual research rows. Manual values remain authoritative; unsupported/vintage cards remain manual. Offline failures retain the last valid prices and show a clear status. Scanner startup fix and Android camera launch tests are retained.

0.10: each new exact duplicate scan increments the existing finish quantity and the top-left quantity badge. The same photo can only contribute one copy, including when OCR is retried. Undo restores the previous count. Choosing a different finish moves the just-scanned copy rather than counting it again. If multiple finishes exist, selection is required before counting the copy. Manual values, condition, notes and purchase data are preserved when quantities increase.

0.11: all eBay price research links now search only DBZ followed by the card code, e.g. DBZ BT2-001. Completed/sold listing filters remain enabled. Card-detail buttons, manual research links and research exports use the same query. Existing automatic market prices, duplicate quantity counters and scanner fixes are retained.

0.33: after a card is saved by scanning, the app refreshes the TCGplayer market feed and checks exact card, set and finish matches. If TCGplayer has no exact match, it checks the saved MNA Cardz reference snapshot. The scan status shows the source lookup and result.

0.34: optional Valo.Data integration checks the eBay raw sold median first for exact English Dragon Ball Super Masters and Fusion World matches. The API key is encrypted with Android Keystore and sent only from the native Android layer; it is not stored in WebView storage or collection backups. If no exact eBay sold sample is available, automatic pricing falls back to TCGplayer market data, then the dated MNA Cardz snapshot. eBay median sample count, observation date, EUR amount and AUD conversion are retained. The free sandbox has a monthly credit cap and is for personal, non-commercial use. Japanese Heroes, Panini, vintage Score and other unsupported product lines continue through available TCGplayer/MNA references and manual source links.

DBZ Vault Android 0.35 adds a remembered compact List view in My portfolio. Each binder row shows its card number, finish, quantity, and saved total value; tap a row to open card details. Grid view remains available from the same toggle.

DBZ Vault Android 0.36 fixes the portfolio view controls: Grid and List are shown as separate selected options. Grid card artwork is constrained to a consistent portrait frame with the full card visible; compact List uses fixed-size thumbnails. Search and sort stack on narrow phone screens.

DBZ Vault Android 0.37 improves automatic pricing. New scans continue to check all available sources automatically. The monthly portfolio sweep now runs after a native feed refresh instead of treating a TCGplayer-only background update as a complete eBay/TCGplayer/MNA check. Existing saved TCGplayer prices are still considered when the live feed is offline. A recent exact check is cached to avoid repeated eBay requests when the same card is scanned. Exact MNA normal-price data can now be used as a clearly labelled foil fallback. Android now serves the latest portfolio stylesheet correctly.

DBZ Vault Android 0.38 fixes automatic MNA price loading. A single exact code, set, product-line and card-name match now uses the saved retailer price even when the listing was out of stock at snapshot time. The price remains labeled as an MNA asking-price guide, with its snapshot date and stock status; ambiguous or variant-colliding rows are still left unmatched. Existing recent no-match results are rechecked under the updated rules.

DBZ Vault Android 0.39 ensures a failed live TCGplayer refresh does not stop automatic price checks. The lookup continues with the saved TCGplayer feed and then the exact MNA Cardz snapshot, while preserving source priority and existing saved prices. Existing price checks are retried under the updated lookup rules.

DBZ Vault Android 0.40 fixes binder saves when WebView local storage is full. Android now keeps a durable native copy of the binder and restores the newest saved copy; browser storage remains a best-effort mirror. Existing binder content is retained during migration.

DBZ Vault Android 0.41 automatically checks the exact TCGplayer candidate feed for a unique card-code, set, line and language match. Parenthetical set labels in product titles no longer block exact card-name matching. For a Foil binder entry with no priced foil candidate, the unique Normal price is recorded as a clearly labeled fallback, according to the collector preference.

DBZ Vault Android 0.42 shows a successfully auto-applied source price directly on the card details and hides the “Remember this version” step when a price has already matched. Cards without a unique exact match still offer manual version review.

DBZ Vault Android 0.43 keeps one automatically updated DBZ-Vault-Backup.json in Downloads and the app private files. It contains binder entries, verified and automatic prices, pricing rules state, compact price history and manual card photos. History snapshots are compacted and written through Android storage to avoid WebView local-storage quota failures.

DBZ Vault Android 0.44 defaults scanned cards to Foil / Holo, with Normal shown as the alternate choice. On first launch, existing binder entries are migrated to Foil / Holo; duplicate Normal and Foil entries for the same card merge their quantities. Manual values and card details are preserved, and saved Foil prices are refreshed against the available sources after migration. This is a one-time conversion; later Normal choices remain unchanged.

DBZ Vault Android 0.45 improves exact MNA Cardz matching for existing cards. Set-code aliases such as TB02/TB2 and rarity prefixes or suffixes such as CP are normalized. Automatic matches still require the exact printed card code, product line, card name and one unique listing. Price checks rerun under the updated matching rules.
