"""Daily server-side TCGCSV sync. No user collection is transmitted."""
import base64, concurrent.futures, datetime, gzip, html, json, re, threading, time, urllib.request, urllib.error
from pathlib import Path
CATEGORIES={23:'Dragon Ball Z TCG (Panini)',27:'Masters',80:'Fusion World'}
BASE='https://tcgcsv.com'
MATCHER_VERSION=3
# Reviewed standard holographic cards that TCGplayer calls "Normal".
# Product IDs pin the original printing, never a promo, reprint or alternate art.
STANDARD_HOLO_PRINTINGS={'BT2-001':148754,'BT1-031':137477}
LOCK=threading.Lock();LAST=0

def norm(s):return re.sub(r'[^A-Z0-9]','',str(s).upper())
def setnorm(s):return norm(re.sub(r'\[[^]]*\]|^Panini:\s*|^Z\d+\s*[·:-]\s*','',s,flags=re.I))
def same_name(card,product):
 name=html.unescape(product['name'])
 if norm(name)==norm(html.unescape(card['name'])):return True
 # Masters leaders are sold as one double-sided card; the catalogue uses its front name.
 sides=name.split('//')
 return card['line']=='Masters' and len(sides)==2 and all(x.strip() for x in sides) and norm(sides[0])==norm(html.unescape(card['name']))
def same_set(card,group):
 return norm(card['set_code'])==norm(group.get('abbreviation','')) or setnorm(card['set_name'])==setnorm(group['name'])
def read_url(url):
 global LAST
 for attempt in range(3):
  with LOCK:
   time.sleep(max(0,.27-(time.monotonic()-LAST)));LAST=time.monotonic()
  try:
   with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'DBZVault/0.5 (personal collection daily price sync)'}),timeout=40) as r:return r.read().decode()
  except urllib.error.HTTPError as e:
   if e.code==404:return None
   if e.code not in (429,500,502,503,504):raise
   if attempt==2:raise
  except (OSError,TimeoutError):
   if attempt==2:raise
  time.sleep(2*(attempt+1))

def get_rows(path):
 raw=read_url(BASE+path)
 if raw is None:return []
 data=json.loads(raw)
 if not data.get('success'):raise ValueError('Source request was not successful: '+path)
 return data['results']

def match_group(cards,group,products,prices,rate):
 """Conservative exact matches only: line, set, code, name, base variant, finish."""
 result={};by_product={}
 for row in prices:by_product.setdefault(row['productId'],[]).append(row)
 for c in cards:
  if c.get('line') not in CATEGORIES.values() or c.get('language')!='English' or c.get('variant','Base')!='Base' or '_' in c['card_number'] or not same_set(c,group):continue
  candidates=[]
  for p in products:
   if p.get('presaleInfo',{}).get('isPresale'):continue
   ext={x['name']:x.get('value','') for x in p.get('extendedData',[])}
   number=ext.get('Number','')
   if not number or number in ('N/A','-'):continue
   keys={norm(number),norm(c['set_code']+'-'+number)}
   if norm(c['card_number']) not in keys:continue
   if not same_name(c,p):continue
   if re.search(r'alt(?:ernate)?[ -]?art|parallel|signature|championship|winner|pre.?release|stamped|promo',p['name'],re.I):continue
   candidates.append(p)
  if len(candidates)!=1:continue
  p=candidates[0]
  for row in by_product.get(p['productId'],[]):
   subtype=row.get('subTypeName','')
   finish={'Normal':'Normal','Foil':'Foil','Holofoil':'Foil','Parallel Foil':'Foil'}.get(subtype)
   usd=row.get('marketPrice')
   if not finish or not isinstance(usd,(int,float)) or isinstance(usd,bool) or not 0<usd<1000000:continue
   key=c['card_number']+'@@'+finish
   quote={'usd':usd,'aud':round(usd*rate,2),'productId':p['productId'],'line':c['line'],'language':'English','name':c['name'],'set':c['set_name'],'finish':finish,'sourceFinish':subtype,'productName':p['name']}
   if key in result:result[key]=None # Ambiguous subtypes never overwrite one another.
   else:result[key]=quote
  standard=result.get(c['card_number']+'@@Normal')
  foil_key=c['card_number']+'@@Foil'
  if standard and STANDARD_HOLO_PRINTINGS.get(c['card_number'])==p['productId'] and foil_key not in result:
   result[foil_key]={**standard,'finish':'Foil','printingNote':'Standard holographic printing; TCGplayer labels this product Normal.'}
 return {k:v for k,v in result.items() if v is not None}

def main():
 root=Path(__file__).resolve().parents[1]
 source=(root/'app/src/main/assets/index.html').read_text()
 encoded=re.search(r'<script id="builtin-catalog"[^>]*>(.*?)</script>',source,re.S)[1]
 catalog=json.loads(gzip.decompress(base64.b64decode(encoded)))['cards']
 output=root/'app/src/main/assets/market-prices.json'
 previous=json.loads(output.read_text()) if output.exists() else None
 source_date=read_url(BASE+'/last-updated.txt').strip()
 if previous and previous.get('sourceUpdated')==source_date and previous.get('matcherVersion')==MATCHER_VERSION:
  print('Source unchanged; retaining daily snapshot.');return
 fx=json.loads(read_url('https://api.frankfurter.dev/v2/rate/usd/aud'))
 rate=float(fx['rate']);assert .1<rate<10
 jobs=[]
 for cid,line in CATEGORIES.items():
  cards=[c for c in catalog if c['line']==line]
  for group in get_rows(f'/tcgplayer/{cid}/groups'):
   selected=[c for c in cards if same_set(c,group)]
   if selected:jobs.append((cid,group,selected))
 print('Syncing',len(jobs),'matching sets',flush=True)
 def job(item):
  cid,group,cards=item;gid=group['groupId']
  products=get_rows(f'/tcgplayer/{cid}/{gid}/products');prices=get_rows(f'/tcgplayer/{cid}/{gid}/prices')
  mapped=match_group(cards,group,products,prices,rate)
  print(group['name'],len(mapped),'exact priced finishes',flush=True)
  return mapped
 quotes={};ambiguous=set()
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
  for mapped in pool.map(job,jobs):
   for k,v in mapped.items():
    if k in quotes and quotes[k]!=v:ambiguous.add(k)
    else:quotes[k]=v
 for k in ambiguous:quotes.pop(k,None)
 if not quotes:raise RuntimeError('No exact prices available; refusing to replace the last good feed')
 snapshot={'schema':1,'matcherVersion':MATCHER_VERSION,'source':'TCGplayer market via TCGCSV','sourceUpdated':source_date,'updated':datetime.datetime.now(datetime.timezone.utc).isoformat(),'currency':'AUD','usdToAud':rate,'fxDate':fx['date'],'fxSource':'Frankfurter','quotes':quotes}
 output.write_text(json.dumps(snapshot,separators=(',',':'),ensure_ascii=False))
 print('Wrote',len(quotes),'exact market prices',flush=True)
if __name__=='__main__':main()
