import importlib.util,unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location('sync',Path(__file__).parents[1]/'scripts/sync_prices.py');sync=importlib.util.module_from_spec(spec);spec.loader.exec_module(sync)
class PricingTests(unittest.TestCase):
 def setUp(self):
  self.c={'card_number':'FB01-003','name':'Vados','language':'English','line':'Fusion World','set_name':'Awakened Pulse','set_code':'FB01','variant':'Base'}
  self.g={'name':'Awakened Pulse','abbreviation':'FB01'}
  self.p={'productId':42,'name':'Vados','extendedData':[{'name':'Number','value':'FB01-003'}]}
  self.prices=[{'productId':42,'subTypeName':'Normal','marketPrice':2}]
 def runmap(self,c=None,p=None,prices=None,g=None):return sync.match_group([c or self.c],g or self.g,p or [self.p],prices if prices is not None else self.prices,1.5)
 def test_exact_usd_conversion(self):self.assertEqual(self.runmap()['FB01-003@@Normal']['aud'],3)
 def test_no_japanese_cross_language(self):self.assertEqual(self.runmap(c={**self.c,'language':'Japanese'}),{})
 def test_no_different_set(self):self.assertEqual(self.runmap(g={'name':'Blazing Aura','abbreviation':'FB02'}),{})
 def test_no_alternate_guess(self):self.assertEqual(self.runmap(c={**self.c,'variant':'Alternate Art'}),{})
 def test_duplicate_product_rejected(self):self.assertEqual(self.runmap(p=[self.p,{**self.p,'productId':43}]),{})
 def test_null_zero_negative_are_unpriced(self):
  for value in [None,0,-1,True]:self.assertEqual(self.runmap(prices=[{**self.prices[0],'marketPrice':value}]),{})
 def test_foil_is_separate(self):self.assertIn('FB01-003@@Foil',self.runmap(prices=[{**self.prices[0],'subTypeName':'Holofoil'}]))
 def test_low_asking_price_not_market_price(self):self.assertEqual(self.runmap(prices=[{'productId':42,'subTypeName':'Normal','lowPrice':2,'marketPrice':None}]),{})
 def test_vintage_manual_cards_excluded(self):self.assertEqual(self.runmap(c={**self.c,'line':'Vintage Score','language':'Other'}),{})
if __name__=='__main__':unittest.main()
