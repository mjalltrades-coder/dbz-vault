import importlib.util,unittest,json
from pathlib import Path
spec=importlib.util.spec_from_file_location('sync',Path(__file__).parents[1]/'scripts/sync_prices.py');sync=importlib.util.module_from_spec(spec);spec.loader.exec_module(sync)
class PricingTests(unittest.TestCase):
 def setUp(self):
  self.c={'card_number':'FB01-003','name':'Vados','language':'English','line':'Fusion World','set_name':'Awakened Pulse','set_code':'FB01','variant':'Base'}
  self.g={'name':'Awakened Pulse','abbreviation':'FB01'}
  self.p={'productId':42,'name':'Vados','extendedData':[{'name':'Number','value':'FB01-003'}]}
  self.prices=[{'productId':42,'subTypeName':'Normal','marketPrice':2}]
 def runmap(self,c=None,p=None,prices=None,g=None):return sync.match_group([c or self.c],g or self.g,p or [self.p],prices if prices is not None else self.prices,1.5)
 def test_exact_usd_conversion(self):self.assertEqual(self.runmap()['FB01-003@@Normal']['aud'],3)
 def test_no_japanese_cross_language(self):self.assertEqual(self.runmap(c={**self.c,'language':'Japanese'}),{})
 def test_no_different_set(self):self.assertEqual(self.runmap(g={'name':'Blazing Aura','abbreviation':'FB02'}),{})
 def test_no_alternate_guess(self):self.assertEqual(self.runmap(c={**self.c,'variant':'Alternate Art'}),{})
 def test_duplicate_product_rejected(self):self.assertEqual(self.runmap(p=[self.p,{**self.p,'productId':43}]),{})
 def test_null_zero_negative_are_unpriced(self):
  for value in [None,0,-1,True]:self.assertEqual(self.runmap(prices=[{**self.prices[0],'marketPrice':value}]),{})
 def test_foil_is_separate(self):self.assertIn('FB01-003@@Foil',self.runmap(prices=[{**self.prices[0],'subTypeName':'Holofoil'}]))
 def test_parallel_foil_is_separate(self):
  quotes=self.runmap(prices=[*self.prices,{**self.prices[0],'subTypeName':'Parallel Foil','marketPrice':7}])
  self.assertEqual(quotes['FB01-003@@Normal']['aud'],3)
  self.assertEqual(quotes['FB01-003@@Foil']['aud'],10.5)
 def test_awakened_leader_name(self):
  c={**self.c,'line':'Masters','name':'Vegito','card_number':'BT2-001','set_code':'BT2','set_name':'Union Force'}
  p={**self.p,'name':'Vegito // Fusion Warrior Super Saiyan Vegito','extendedData':[{'name':'Number','value':'BT2-001'}]}
  g={'name':'Union Force','abbreviation':'DBS-B02'}
  self.assertIn('BT2-001@@Normal',self.runmap(c=c,p=[p],g=g))
  for name in ['Vegito (Winner) // Fusion Warrior Super Saiyan Vegito','Vegito // Fusion Warrior Super Saiyan Vegito (Promo)']:
   self.assertEqual(self.runmap(c=c,p=[{**p,'name':name}],g=g),{})
 def test_prefixed_catalogue_set(self):
  self.assertEqual(sync.setnorm('Z07 · Beyond Generations'),sync.setnorm('Beyond Generations'))
  self.assertEqual(sync.setnorm('UW06 · Saiyan Showdown'),sync.setnorm('Saiyan Showdown'))
  self.assertEqual(sync.setnorm('Themed Booster · World Martial Arts Tournament'),sync.setnorm('World Martial Arts Tournament'))
  self.assertEqual(sync.setnorm('Expansion Deck Box Set 09: Saiyan Surge'),sync.setnorm('Saiyan Surge'))
  self.assertEqual(sync.setnorm('Special Anniversary Box 2020'),sync.setnorm('Special Anniversary Set 2020'))
 def test_code_padding_requires_same_prefix(self):
  self.assertEqual(sync.codekey('EX13-35'),sync.codekey('EX13-035'))
  self.assertNotEqual(sync.codekey('BT1-031'),sync.codekey('BT2-031'))
  self.assertNotEqual(sync.codekey('BM11-ASEC2'),sync.codekey('BM11-SEC2'))
 def test_reported_binder_cards_with_real_provider_records(self):
  fixtures=json.loads((Path(__file__).parent/'fixtures/binder-products.json').read_text())
  expected={148754:('BT2-001','Vegito','BT2','Union Force',.39),137477:('BT1-031','God Break Son Goku','BT1','Galactic Battle',.84),538848:('BT24-033','SS3 Son Goku','BT24','Z07 · Beyond Generations',2.69)}
  for item in fixtures:
   p=item['product'];number,name,code,set_name,aud=expected[p['productId']]
   c={**self.c,'line':'Masters','card_number':number,'name':name,'set_code':code,'set_name':set_name}
   g={'name':set_name,'abbreviation':code}
   quotes=self.runmap(c=c,p=[p],prices=item['prices'],g=g)
   self.assertEqual(quotes[number+'@@Foil']['aud'],aud)
 def test_standard_holo_alias_never_applies_to_another_product(self):
  c={**self.c,'line':'Masters','card_number':'BT1-031','name':'God Break Son Goku','set_code':'BT1','set_name':'Galactic Battle'}
  p={**self.p,'name':c['name'],'extendedData':[{'name':'Number','value':c['card_number']}]}
  self.assertNotIn('BT1-031@@Foil',self.runmap(c=c,p=[p],g={'name':c['set_name'],'abbreviation':'BT1'}))
 def test_low_asking_price_not_market_price(self):self.assertEqual(self.runmap(prices=[{'productId':42,'subTypeName':'Normal','lowPrice':2,'marketPrice':None}]),{})
 def test_review_candidates_keep_versions_separate(self):
  products=[self.p,{**self.p,'productId':43,'name':'Vados (Alternate Art)'}]
  prices=self.prices+[{**self.prices[0],'productId':43,'marketPrice':20}]
  rows=sync.review_candidates([self.c],self.g,products,prices,1.5)[self.c['card_number']]
  self.assertEqual({r['productId'] for r in rows},{42,43})
  self.assertEqual(rows[1]['aud'],30)
  self.assertEqual(sync.review_candidates([self.c],{'name':'Wrong set'},products,prices,1.5),{})
  self.assertEqual(sync.review_candidates([{**self.c,'language':'Japanese'}],self.g,products,prices,1.5),{})
 def test_review_candidates_reject_missing_market_and_wrong_number(self):
  self.assertEqual(sync.review_candidates([self.c],self.g,[{**self.p,'extendedData':[{'name':'Number','value':'FB01-004'}]}],self.prices,1.5),{})
  self.assertEqual(sync.review_candidates([self.c],self.g,[self.p],[{**self.prices[0],'marketPrice':None,'lowPrice':2}],1.5),{})
 def test_vintage_manual_cards_excluded(self):self.assertEqual(self.runmap(c={**self.c,'line':'Vintage Score','language':'Other'}),{})
if __name__=='__main__':unittest.main()
