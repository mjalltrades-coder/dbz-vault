const {chromium}=require('playwright'),fs=require('fs'),path=require('path'),assert=require('node:assert/strict');
(async()=>{
const browser=await chromium.launch({executablePath:process.env.DBZ_TEST_CHROME,headless:true,args:['--no-sandbox']});
const page=await browser.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
const base=path.resolve('app/src/main/assets'),now=new Date().toISOString();let fresh=false,missing=false,offline=false;
const card={number:'EX09-01',finish:'Foil',qty:2,condition:'Raw / Near Mint',valueAUD:100,added:'2026-10-20'};
function feed(live){const usd=live?4:2;const q={usd,aud:usd*1.5,productId:206175,line:'Masters',name:'Son Goku, Nimbus Voyager',set:'Saiyan Surge',language:'English',finish:'Normal'};
const row={...q,card_number:'EX09-01',sourceFinish:'Normal',source_url:'https://www.tcgplayer.com/product/206175',image_url:'https://tcgplayer-cdn.tcgplayer.com/product/206175_200w.jpg'};
return {schema:1,matcherVersion:4,currency:'AUD',source:'TCGplayer market via TCGCSV',updated:now,fxDate:'2026-10-23',fxSource:'Frankfurter',usdToAud:1.5,quotes:{'EX09-01@@Normal':q},candidates:{'EX09-01':missing?[]:[row,{...row,productId:99,name:'Other version',source_url:'https://www.tcgplayer.com/product/99',usd:50,aud:75}]}};}
await page.route('**/*',async r=>{const u=new URL(r.request().url());if(u.hostname==='appassets.androidplatform.net'){if(path.basename(u.pathname)==='market-prices.json')return r.fulfill({json:feed(false)});const file=path.join(base,path.basename(u.pathname));if(fs.existsSync(file))return r.fulfill({path:file,contentType:file.endsWith('.js')?'application/javascript':file.endsWith('.json')?'application/json':'text/html'});}if(u.hostname==='raw.githubusercontent.com')return offline?r.abort():r.fulfill({json:feed(true)});return r.abort();});
await page.addInitScript(({card,now})=>{if(!localStorage.getItem('seeded')){localStorage.setItem('dbz_vault_2026_v1',JSON.stringify({version:1,cards:[card,{number:'BM1-SEC',finish:'Foil',qty:1,condition:'Raw / Near Mint',valueAUD:0,added:'2026-10-20'}]}));localStorage.setItem('dbz-vault-website-pricing-v1',JSON.stringify({version:1,quotes:{},checks:{},mappings:{},suggestions:{},monthly:{completed_at:now}}));localStorage.setItem('seeded','1');}},{card,now});
await page.goto('https://appassets.androidplatform.net/assets/index.html');await page.waitForFunction(()=>window.DBZWebsitePricing&&document.getElementById('stat-owned').textContent==='3');
await page.evaluate(()=>openCard('EX09-01','Foil'));await page.waitForSelector('[data-tcg-version="0"]');
assert.equal(await page.evaluate(()=>valuationInfo('EX09-01','Foil').price),100);
page.once('dialog',d=>d.accept());await page.locator('[data-tcg-version="0"]').click();
assert.equal(await page.evaluate(()=>DBZWebsitePricing.state.mappings['EX09-01@@Foil'].product_id),206175);
assert.equal(await page.evaluate(()=>valuationInfo('EX09-01','Foil').price),100,'remembering a version must preserve manual price');
page.once('dialog',d=>d.accept());await page.getByRole('button',{name:'Accept this price',exact:true}).click();
assert.equal(await page.evaluate(()=>valuationInfo('EX09-01','Foil').price),3);
await page.locator('#website-update').click();await page.waitForFunction(()=>valuationInfo('EX09-01','Foil').price===6);
assert.equal(await page.evaluate(()=>owned.get('EX09-01@@Foil').qty),2);
missing=true;await page.locator('#website-update').click();await page.waitForFunction(()=>!document.getElementById('website-update').disabled);assert.equal(await page.evaluate(()=>valuationInfo('EX09-01','Foil').price),6,'missing selected product must not substitute another printing');
offline=true;await page.locator('#website-update').click();await page.waitForFunction(()=>!document.getElementById('website-update').disabled);assert.equal(await page.evaluate(()=>valuationInfo('EX09-01','Foil').price),6);
await page.reload();await page.waitForFunction(()=>window.DBZWebsitePricing);assert.equal(await page.evaluate(()=>DBZWebsitePricing.state.mappings['EX09-01@@Foil'].product_id),206175);
await page.evaluate(()=>openCard('BM1-SEC','Foil'));await page.waitForFunction(()=>document.querySelectorAll('[data-mna]').length>=2);assert.equal(await page.evaluate(()=>DBZWebsitePricing.state.mappings['BM1-SEC@@Foil']),undefined);
assert.equal(await page.locator('#mna-candidates img').count()>=2,true,'ambiguous MNA versions show artwork');assert.equal(errors.length,0,errors.join('\n'));
await browser.close();console.log('Version UI passed: pictured choices, manual-price protection, explicit acceptance, pinned refresh, missing/offline retention, reload persistence, MNA ambiguity.');
})().catch(e=>{console.error(e);process.exit(1)});
