# DBZ Vault 0.12 — website pricing

This update retains application ID `com.dbzvault.collector.nativescan`, WebView origin `https://appassets.androidplatform.net`, collection key `dbz_vault_2026_v1`, saved sold-price key, photo databases, and the existing signing certificate. Install over version 0.11; do not uninstall or clear app storage. Export a collection backup before installing.

## Pricing behavior

- eBay is the primary comparable source. Searches use `dragon ball z <printed code>` (plus `Japanese` for Japanese cards), Collectables category 1, Sold and Completed filters, Worldwide item location, and most recently ended ordering. Exact printing, language, finish, grade and condition must be verified; hidden Best Offer values cannot be assumed. A verified sold price can be saved with source URL, original currency, amount, AUD conversion rate, FX source/date, observation date and lookup date. Major international eBay marketplaces and currencies are supported.
- TCGplayer Market Price is secondary, via the app's existing server-side TCGCSV cache. Client devices request only the app's price feed. Matching checks code, game, set, name, base printing, language and finish. The price is a product-level sales aggregate; SKU/condition-specific prices are not provided. Automatic matching is restricted to English base cards in raw/Near Mint condition. Other conditions require manual exact-comparable research.
- MNA Cardz is a third-priority retailer asking-price guide, never a completed sale. The 3,975 supplied records are a separate reference catalogue keyed by source product ID. They do not become owned cards. Five blank-code/noncard records are not automatic matches. Every selected MNA product needs explicit exact-product review; this also protects the 230 reused card codes. Multiple-variant products are excluded from the simple reference selector. Snapshot: 24 October 2026, USD to AUD 1.422888, supplied FX timestamp retained.
- Existing manual values are protected. New lower-priority values become review suggestions. Missing values, invalid conversions and failed lookups never zero existing prices. Distinct finishes have distinct prices; binder totals multiply unit price by owned quantity.
- Three taps on the same binder tile within 900 ms refresh that item only. Single tap opens its details after the recognition window. Keyboard/accessibility activation opens details immediately. Update Price in details invokes the same refresh. No overlapping price jobs are allowed.
- Full binder check: every 30 days. Android WorkManager checks eligibility daily with a network constraint, downloads the cached server feed and checks a local read-only binder mirror. Results are merged at app resume after identity checks. Launch/resume also catches overdue checks. Android may defer background work; failed jobs retry with exponential backoff. The app shows last completed check, next due, checked count, errors, and unavailable sources. A completed check means all binder records were evaluated against available sources, not that every website supplied fresh data.
- Exported collection backups now include website price provenance, reviewed MNA product mappings, suggestions and monthly status. Existing backup format remains supported.

## Availability limits

- eBay sold-data automation is not enabled. Marketplace Insights requires special developer approval. The app opens sold searches and supports user-verified saving; it does not scrape or invent completed sales. https://developer.ebay.com/api-docs/buy/marketplace-insights/static/overview.html
- TCGplayer direct API access is closed to new applicants. The existing TCGCSV backend is retained under that provider's published server-side caching guidelines. https://docs.tcgplayer.com/docs/getting-started and https://tcgcsv.com/docs
- MNA live automated refresh is not enabled: no verified permitted live price integration was established in this task. The supplied snapshot remains visibly dated; browsing its current product page and manually saving a checked guide value is supported. https://mnacardz.com/collections/all-sdbh-singles
- Existing legacy manual values had no original-currency metadata. These remain intact and are labelled as legacy instead of inventing provenance.

## Validation

`node tests/website-pricing.test.cjs`
`node tests/market.test.cjs`
`node tests/recognition.test.cjs`
`node tests/portfolio.test.cjs`
`python3 -m unittest discover -s tests -p 'test_*.py'`

The Playwright UI suite `tests/website-ui.test.cjs` covers preservation of seeded collection data, single-card triple-tap isolation, Update Price, international sold-search parameters, exact EX09-01 product link, ambiguous MNA review, verified manual saving, offline retention, full binder checks and backup provenance. Set `DBZ_TEST_CHROME` to a Chromium executable when running it locally.

Android compile and lint: Gradle 8.9 / JDK 17, `gradle lintDebug assembleDebug`. The existing scanner source and tests remain included. The resulting APK certificate was compared with DBZ-Vault-Simple-eBay.apk. Physical-device installation and Android background scheduling still require device verification.


## Version 0.15 — remember exact product versions

The card detail screen now shows exact-code/set TCGplayer products and the MNA reference products with artwork. Remembering a version pins the product ID and source printing to the binder card's game, set, language, variant, finish and condition. This is a product identity confirmation, not a price lock: future checks use that product when it remains available. A source's Normal subtype is never automatically assigned to a Foil binder entry; it requires explicit physical-printing confirmation. Missing products do not select another printing. Changed conditions or finishes invalidate the selection. Product-level TCGplayer pricing is limited to raw Near Mint cards.

Saved manual/eBay prices remain protected. An explicit Accept this price action can replace a saved value after confirmation. MNA remains a dated retailer-guide snapshot, not live sold data. Mappings and suggestions remain in collection backups. The existing whole-binder Update card prices button, 30-day schedule, launch catch-up and single-card triple tap all reuse remembered mappings. eBay queries use only dragon ball z followed by the exact card code, with worldwide sold filters. No collection backup is bundled or published.

Additional verification: node tests/version-ui.test.cjs and expanded pricing rule/exporter tests.


## Version 0.16 — user-approved Normal-price fallback

When no exact Foil quote exists, an exact matching Normal quote may value the Foil binder entry, labelled Normal price used — foil unavailable. Code, game, set, name, language and raw Near Mint matching still apply. A pinned product only falls back to the Normal subtype of the same product ID, never a different version sharing its code. If the Foil quote returns, it takes precedence. Existing manually saved prices remain protected, and an existing known Foil market quote is retained for review instead of silently downgraded to a Normal reference. The physical card remains marked Foil; quantities and finish selections are unchanged.
