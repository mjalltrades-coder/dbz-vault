DBZ Vault — Android APK Build

This ZIP contains the full Android project and a GitHub Actions APK build workflow.
The ZIP itself is NOT an APK.

To build using GitHub:
1. Upload the CONTENTS of this project folder into the ROOT of the GitHub repository.
   Important: .github/workflows/build-apk.yml must be at the repository root.
2. In GitHub, open Actions > Build DBZ Vault APK > Run workflow.
3. When the build completes, open the workflow run and download the DBZ-Vault-Android-APK artifact.
4. Unzip the downloaded artifact and install app-debug.apk on Android.

The GitHub Actions build has not been executed or verified in this environment.
