package com.dbzvault.collector;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.webkit.WebView;
import android.app.Instrumentation;
import androidx.camera.view.PreviewView;
import java.util.concurrent.atomic.AtomicBoolean;
import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.rule.GrantPermissionRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class ScannerLaunchTest {
  @Rule public GrantPermissionRule camera=GrantPermissionRule.grant(Manifest.permission.CAMERA);
  private String text(View view) {
    StringBuilder result=new StringBuilder();
    if(view instanceof TextView)result.append(((TextView)view).getText()).append('\n');
    if(view instanceof ViewGroup)for(int i=0;i<((ViewGroup)view).getChildCount();i++)result.append(text(((ViewGroup)view).getChildAt(i)));
    return result.toString();
  }
  private <T extends View> T find(View view,Class<T> type) {
    if(type.isInstance(view))return type.cast(view);
    if(view instanceof ViewGroup)for(int i=0;i<((ViewGroup)view).getChildCount();i++){
      T child=find(((ViewGroup)view).getChildAt(i),type);if(child!=null)return child;
    }
    return null;
  }
  @Test public void cameraOpensAndReopensWithoutCrashing() {
    Context context=InstrumentationRegistry.getInstrumentation().getTargetContext();
    for(int attempt=0;attempt<2;attempt++) {
      try(ActivityScenario<ScannerActivity> screen=ActivityScenario.launch(new Intent(context,ScannerActivity.class))) {
        AtomicBoolean streaming=new AtomicBoolean();
        long deadline=SystemClock.uptimeMillis()+15000;
        while(!streaming.get()&&SystemClock.uptimeMillis()<deadline){
          screen.onActivity(activity->{PreviewView preview=find(activity.findViewById(android.R.id.content),PreviewView.class);streaming.set(preview!=null&&preview.getPreviewStreamState().getValue()==PreviewView.StreamState.STREAMING);});
          SystemClock.sleep(200);
        }
        assertTrue("Camera preview should stream frames",streaming.get());
        screen.onActivity(activity->{
          View root=activity.findViewById(android.R.id.content);
          String labels=text(root);
          assertTrue(labels.contains("Read now"));
          assertTrue(labels.contains("Gallery"));
          assertFalse(labels,labels.contains("Could not start camera"));
          assertFalse(activity.isFinishing());
        });
      }
    }
  }
  @Test public void scanTabAndNativeBridgeOpenCamera() {
    Instrumentation instrumentation=InstrumentationRegistry.getInstrumentation();
    Instrumentation.ActivityMonitor monitor=instrumentation.addMonitor(ScannerActivity.class.getName(),null,false);
    try(ActivityScenario<MainActivity> home=ActivityScenario.launch(MainActivity.class)) {
      SystemClock.sleep(5000);
      home.onActivity(activity->{
        WebView web=find(activity.findViewById(android.R.id.content),WebView.class);
        assertNotNull(web);
        web.evaluateJavascript("document.querySelector('[data-tab=scan]').click(); window.dbzOpenNumberCamera();",null);
      });
      android.app.Activity scanner=instrumentation.waitForMonitorWithTimeout(monitor,15000);
      assertNotNull("Scan tab and JS bridge must open the native scanner",scanner);
      SystemClock.sleep(3000);
      instrumentation.runOnMainSync(()->{assertFalse(scanner.isFinishing());assertTrue(text(scanner.findViewById(android.R.id.content)).contains("Read now"));scanner.finish();});
    } finally {instrumentation.removeMonitor(monitor);}
  }
}
