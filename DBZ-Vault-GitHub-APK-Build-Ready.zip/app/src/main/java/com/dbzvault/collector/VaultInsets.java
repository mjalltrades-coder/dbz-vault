package com.dbzvault.collector;

import android.app.Activity;
import android.view.View;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

/** Keep HTML and scanner controls inside the usable screen, including the IME. */
final class VaultInsets {
  private VaultInsets() {}
  static void apply(Activity activity,View container,int gap) {
    activity.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
    WindowCompat.setDecorFitsSystemWindows(activity.getWindow(),false);
    WindowCompat.getInsetsController(activity.getWindow(),container)
        .setAppearanceLightStatusBars(false);
    WindowCompat.getInsetsController(activity.getWindow(),container)
        .setAppearanceLightNavigationBars(false);
    ViewCompat.setOnApplyWindowInsetsListener(container,(view,insets)->{
      int types=WindowInsetsCompat.Type.systemBars()|WindowInsetsCompat.Type.displayCutout()
          |WindowInsetsCompat.Type.ime();
      Insets safe=insets.getInsets(types);
      view.setPadding(safe.left+gap,safe.top+gap,safe.right+gap,safe.bottom+gap);
      // Forward zero values so newer WebViews never add a second safe area.
      return new WindowInsetsCompat.Builder(insets).setInsets(types,Insets.NONE).build();
    });
  }
}
