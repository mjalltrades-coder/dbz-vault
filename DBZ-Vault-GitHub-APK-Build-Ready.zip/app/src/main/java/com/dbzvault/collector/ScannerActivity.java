package com.dbzvault.collector;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Size;
import android.view.Gravity;
import android.view.MotionEvent;
import android.widget.*;
import androidx.activity.ComponentActivity;
import androidx.camera.core.*;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.io.File;
import java.util.*;
import java.util.concurrent.*;

public class ScannerActivity extends ComponentActivity {
  static volatile Set<String> knownCodes=Collections.emptySet();
  private final TextRecognizer reader=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
  private final ExecutorService executor=Executors.newSingleThreadExecutor();
  private PreviewView preview; private TextView status; private ImageCapture capture;
  private ProcessCameraProvider provider; private Camera camera;
  private boolean taking=false,closed=false,torch=false; private String lastCode=""; private int stable=0; private long lastRead=0;
  @Override public void onCreate(Bundle state){
    super.onCreate(state);
    LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);root.setPadding(16,16,16,16);root.setBackgroundColor(Color.rgb(15,20,30));
    status=new TextView(this);status.setTextColor(Color.WHITE);status.setTextSize(17);status.setPadding(8,12,8,12);status.setGravity(Gravity.CENTER);
    status.setText("Auto scan • Hold the card steady, with its printed number clearly visible. Tap the preview to focus.");root.addView(status);
    preview=new PreviewView(this);preview.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);root.addView(preview,new LinearLayout.LayoutParams(-1,0,1));
    LinearLayout buttons=new LinearLayout(this);root.addView(buttons);addButton(buttons,"Read now",()->takePhoto());addButton(buttons,"Gallery",()->gallery());addButton(buttons,"Light",()->{if(camera!=null&&camera.getCameraInfo().hasFlashUnit()){torch=!torch;camera.getCameraControl().enableTorch(torch);}});addButton(buttons,"Close",()->finish());setContentView(root);
    // Install scanner insets only after ComponentActivity has installed its view-tree owners.
    // The native camera has no HTML viewport, so leave insets available to CameraX children.
    root.setOnApplyWindowInsetsListener((view,insets)->{
      if(android.os.Build.VERSION.SDK_INT>=30){
        android.graphics.Insets bars=insets.getInsets(android.view.WindowInsets.Type.systemBars()|android.view.WindowInsets.Type.displayCutout());
        view.setPadding(16+bars.left,16+bars.top,16+bars.right,16+bars.bottom);
      }
      return insets;
    });
    root.requestApplyInsets();
    preview.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_UP&&camera!=null){MeteringPoint point=preview.getMeteringPointFactory().createPoint(e.getX(),e.getY());camera.getCameraControl().startFocusAndMetering(new FocusMeteringAction.Builder(point).setAutoCancelDuration(3,TimeUnit.SECONDS).build());v.performClick();}return true;});
    if("gallery".equals(getIntent().getStringExtra("mode"))){if(state==null)gallery();}
    else if(checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)startCamera();
    else requestPermissions(new String[]{Manifest.permission.CAMERA},10);
  }
  private void addButton(LinearLayout row,String label,Runnable action){Button b=new Button(this);b.setText(label);b.setTextSize(11);row.addView(b,new LinearLayout.LayoutParams(0,-2,1));b.setOnClickListener(v->action.run());}
  private void gallery(){startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE),11);}
  @Override public void onRequestPermissionsResult(int code,String[] p,int[] r){super.onRequestPermissionsResult(code,p,r);if(code==10&&r.length>0&&r[0]==PackageManager.PERMISSION_GRANTED)startCamera();else status.setText("Camera permission is needed. You can still scan using Gallery.");}
  @android.annotation.SuppressLint("MissingPermission")
  private void startCamera(){
    com.google.common.util.concurrent.ListenableFuture<ProcessCameraProvider> future=ProcessCameraProvider.getInstance(this);
    future.addListener(()->{try{if(closed)return;provider=future.get();Preview p=new Preview.Builder().build();p.setSurfaceProvider(preview.getSurfaceProvider());capture=new ImageCapture.Builder().setTargetResolution(new Size(1920,1440)).build();ImageAnalysis analysis=new ImageAnalysis.Builder().setTargetResolution(new Size(1920,1440)).setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build();analysis.setAnalyzer(executor,this::analyze);provider.unbindAll();camera=provider.bindToLifecycle(this,CameraSelector.DEFAULT_BACK_CAMERA,p,capture,analysis);}catch(Exception e){status.setText("Could not start camera. Use Gallery or reopen scanner. "+e.getMessage());}},ContextCompat.getMainExecutor(this));
  }
  @androidx.annotation.OptIn(markerClass=androidx.camera.core.ExperimentalGetImage.class)
  private void analyze(ImageProxy frame){
    if(taking||closed||frame.getImage()==null||System.currentTimeMillis()-lastRead<500){frame.close();return;}lastRead=System.currentTimeMillis();
    reader.process(InputImage.fromMediaImage(frame.getImage(),frame.getImageInfo().getRotationDegrees())).addOnSuccessListener(text->{
      Set<String> matches=new HashSet<>();
      for(String line:text.getText().toUpperCase(Locale.ROOT).split("\\n")){
        String normalized=line.replaceAll("[^A-Z0-9]","");
        if(normalized.length()>=5&&normalized.matches(".*[A-Z].*")&&knownCodes.contains(normalized))matches.add(normalized);
        for(String token:line.split("[^A-Z0-9_-]+")){String key=token.replaceAll("[^A-Z0-9]","");if(key.length()>=5&&key.matches(".*[A-Z].*")&&knownCodes.contains(key))matches.add(key);}
      }
      String code=matches.size()==1?matches.iterator().next():"";
      if(!code.isEmpty()&&code.equals(lastCode))stable++;else{lastCode=code;stable=code.isEmpty()?0:1;}
      if(stable>=2&&!taking&&!closed){status.setText("Number detected — capturing card…");takePhoto();}
    }).addOnCompleteListener(t->frame.close());
  }
  private void takePhoto(){if(taking||capture==null||closed)return;taking=true;status.setText("Reading card…");File f=new File(getCacheDir(),"scan-"+System.nanoTime()+".jpg");capture.takePicture(new ImageCapture.OutputFileOptions.Builder(f).build(),ContextCompat.getMainExecutor(this),new ImageCapture.OnImageSavedCallback(){public void onImageSaved(ImageCapture.OutputFileResults r){readFile(f);}public void onError(ImageCaptureException e){taking=false;status.setText("Capture failed. Try again or choose Gallery.");}});}
  private void readFile(File f){try{reader.process(InputImage.fromFilePath(this,Uri.fromFile(f))).addOnSuccessListener(t->{if(closed)return;setResult(RESULT_OK,new Intent().putExtra("photo",f.getAbsolutePath()).putExtra("text",t.getText()));finish();}).addOnFailureListener(e->{taking=false;status.setText("Could not read image. Try a clearer photo.");});}catch(Exception e){taking=false;status.setText("Could not open photo. Choose a JPG or PNG.");}}
  @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(req==11){if(result==RESULT_OK&&data!=null&&data.getData()!=null){taking=true;status.setText("Reading gallery image…");executor.execute(()->{try{File f=new File(getCacheDir(),"gallery-"+System.nanoTime()+".jpg");try(java.io.InputStream in=getContentResolver().openInputStream(data.getData());java.io.OutputStream out=new java.io.FileOutputStream(f)){byte[] b=new byte[8192];int n;long total=0;while((n=in.read(b))!=-1){total+=n;if(total>40*1024*1024)throw new java.io.IOException("Image too large");out.write(b,0,n);}}runOnUiThread(()->readFile(f));}catch(Exception e){runOnUiThread(()->{taking=false;status.setText("Could not open photo. Choose a smaller JPG or PNG.");});}});}else if("gallery".equals(getIntent().getStringExtra("mode")))finish();}}
  @Override protected void onDestroy(){closed=true;if(provider!=null)provider.unbindAll();executor.shutdown();reader.close();super.onDestroy();}
}
