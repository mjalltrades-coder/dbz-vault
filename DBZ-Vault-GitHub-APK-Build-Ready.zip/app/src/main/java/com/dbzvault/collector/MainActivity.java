package com.dbzvault.collector;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import java.io.InputStream;

public class MainActivity extends Activity {
  private WebView web;
  private volatile java.io.File scanFile;
  private java.io.File exportFile;
  private java.io.OutputStream exportStream;
  private String exportId,exportName,exportMime;
  private long exportSize;
  private PermissionRequest pendingCamera;
  private void exportNotice(String message){runOnUiThread(()->{android.widget.Toast.makeText(this,message,android.widget.Toast.LENGTH_LONG).show();if(web!=null)web.evaluateJavascript("window.dbzExportResult && window.dbzExportResult("+org.json.JSONObject.quote(message)+")",null);});}
  private void clearExport(){try{if(exportStream!=null)exportStream.close();}catch(Exception ignored){}exportStream=null;if(exportFile!=null)exportFile.delete();exportFile=null;exportId=null;}

  private ValueCallback<Uri[]> pendingFiles;
  private static final int CAMERA_REQ=20, FILE_REQ=21, SCAN_REQ=22, EXPORT_REQ=23;
  private final com.google.mlkit.vision.text.TextRecognizer reader=com.google.mlkit.vision.text.TextRecognition.getClient(com.google.mlkit.vision.text.latin.TextRecognizerOptions.DEFAULT_OPTIONS);
  private final java.util.concurrent.ExecutorService work=java.util.concurrent.Executors.newSingleThreadExecutor();
  public class NativeScanner {
    @android.webkit.JavascriptInterface public void savePricingBinder(String json){try{new org.json.JSONObject(json);PricingWorker.saveBinder(MainActivity.this,json);}catch(Exception ignored){}}
    @android.webkit.JavascriptInterface public String readPricingResults(){return PricingWorker.readResults(MainActivity.this);}

    @android.webkit.JavascriptInterface public void beginExport(String id,String name,String mime){work.execute(()->{try{if(exportId!=null)throw new Exception("Finish the current export first");exportId=id;exportName=name.replaceAll("[^A-Za-z0-9._-]","_");exportMime=mime.startsWith("text/csv")?"text/csv":mime.startsWith("application/json")?"application/json":"application/octet-stream";exportFile=java.io.File.createTempFile("vault-export-",".tmp",getCacheDir());exportStream=new java.io.FileOutputStream(exportFile);exportSize=0;}catch(Exception e){exportNotice("Export could not start: "+e.getMessage());}});}
    @android.webkit.JavascriptInterface public void writeExportChunk(String id,String chunk){work.execute(()->{try{if(!id.equals(exportId)||exportStream==null)return;byte[] bytes=android.util.Base64.decode(chunk,android.util.Base64.DEFAULT);exportSize+=bytes.length;if(exportSize>100L*1024*1024)throw new Exception("Backup exceeds 100 MB");exportStream.write(bytes);}catch(Exception e){clearExport();exportNotice("Export failed: "+e.getMessage());}});}
    @android.webkit.JavascriptInterface public void finishExport(String id){work.execute(()->{try{if(!id.equals(exportId)||exportStream==null)return;exportStream.close();exportStream=null;runOnUiThread(()->{try{startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(exportMime).putExtra(Intent.EXTRA_TITLE,exportName),EXPORT_REQ);}catch(Exception e){work.execute(()->clearExport());exportNotice("No file-saving app is available");}});}catch(Exception e){clearExport();exportNotice("Export failed");}});}

    @android.webkit.JavascriptInterface public void open(String mode,String codes){
      try {org.json.JSONArray a=new org.json.JSONArray(codes);java.util.Set<String> known=new java.util.HashSet<>();for(int i=0;i<a.length();i++)known.add(a.getString(i));ScannerActivity.knownCodes=known;}catch(Exception ignored){}
      runOnUiThread(()->startActivityForResult(new Intent(MainActivity.this,ScannerActivity.class).putExtra("mode",mode),SCAN_REQ));
    }
    @android.webkit.JavascriptInterface public void recognize(String id,String data){
      work.execute(()->{try{byte[] bytes=android.util.Base64.decode(data.substring(data.indexOf(',')+1),android.util.Base64.DEFAULT);android.graphics.Bitmap bitmap=android.graphics.BitmapFactory.decodeByteArray(bytes,0,bytes.length);if(bitmap==null)throw new Exception("Invalid photo");
        reader.process(com.google.mlkit.vision.common.InputImage.fromBitmap(bitmap,0)).addOnSuccessListener(t->reply(id,t.getText(),null)).addOnFailureListener(e->reply(id,null,e.getMessage())).addOnCompleteListener(t->bitmap.recycle());
      }catch(Exception e){reply(id,null,e.getMessage());}});
    }
  }
  private void reply(String id,String text,String error){runOnUiThread(()->{if(web!=null)web.evaluateJavascript("window.dbzNativeOCRResult("+org.json.JSONObject.quote(id)+","+org.json.JSONObject.quote(text==null?"":text)+","+(error==null?"null":org.json.JSONObject.quote(error))+")",null);});}

  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    PricingWorker.schedule(this);
    // Resize the WebView itself: its padding does not move fixed HTML headers/nav.
    android.widget.FrameLayout root=new android.widget.FrameLayout(this);
    root.setBackgroundColor(android.graphics.Color.rgb(11,16,24));
    web=new WebView(this);
    root.addView(web,new android.widget.FrameLayout.LayoutParams(-1,-1));
    VaultInsets.apply(this,root,0);
    setContentView(root);
    root.requestApplyInsets();

    WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
    s.setAllowFileAccess(false); s.setAllowContentAccess(true); s.setMediaPlaybackRequiresUserGesture(false);
    web.addJavascriptInterface(new NativeScanner(),"DBZNative");
    web.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){
        Uri u=request.getUrl();if("https".equals(u.getScheme())&&"appassets.androidplatform.net".equals(u.getHost()))return false;
        if("https".equals(u.getScheme())||"http".equals(u.getScheme()))try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception ignored){}return true;
      }

      @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request){
        Uri uri=request.getUrl();
        if("appassets.androidplatform.net".equals(uri.getHost()) && uri.getPath()!=null && uri.getPath().startsWith("/assets/")) {
          String name=uri.getPath().substring("/assets/".length());
          if("catalog-art".equals(name)) {
            try{
              Uri source=Uri.parse(uri.getQueryParameter("url"));
              if(!"https".equals(source.getScheme())||!"over9001.com".equals(source.getHost())||source.getUserInfo()!=null||source.getPort()!=-1||source.getPath()==null||!source.getPath().startsWith("/cards/"))throw new java.io.IOException("Unsupported artwork source");
              java.net.HttpURLConnection connection=(java.net.HttpURLConnection)new java.net.URL(source.toString()).openConnection();connection.setInstanceFollowRedirects(false);connection.setConnectTimeout(7000);connection.setReadTimeout(7000);connection.setRequestProperty("User-Agent","DBZVault/0.5 personal-card-artwork");
              if(connection.getResponseCode()!=200)throw new java.io.IOException("Artwork unavailable");
              String mime=connection.getContentType();if(mime==null||!mime.startsWith("image/"))throw new java.io.IOException("Not an image");
              java.io.ByteArrayOutputStream bytes=new java.io.ByteArrayOutputStream();try(InputStream in=connection.getInputStream()){byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1){if(bytes.size()+n>5*1024*1024)throw new java.io.IOException("Artwork too large");bytes.write(buffer,0,n);}}finally{connection.disconnect();}
              return new WebResourceResponse(mime.split(";")[0],null,new java.io.ByteArrayInputStream(bytes.toByteArray()));
            }catch(Exception e){return new WebResourceResponse("text/plain","UTF-8",404,"Not found",java.util.Collections.emptyMap(),new java.io.ByteArrayInputStream(new byte[0]));}
          }
          if("native-scan.jpg".equals(name)) {
            try{java.io.File file=scanFile;if(file!=null)return new WebResourceResponse("image/jpeg",null,new java.io.FileInputStream(file));}catch(Exception ignored){}
            return new WebResourceResponse("text/plain","UTF-8",404,"Not found",java.util.Collections.emptyMap(),new java.io.ByteArrayInputStream(new byte[0]));
          }
          if (!"index.html".equals(name) && !"market-prices.json".equals(name) && !"pricing-engine.js".equals(name) && !"website-pricing.js".equals(name) && !"mna-reference.json".equals(name)) return null;
          try { InputStream in=getAssets().open(name); return new WebResourceResponse(name.endsWith(".json")?"application/json":name.endsWith(".js")?"application/javascript":"text/html","UTF-8",in); }
          catch(Exception ignored) { return null; }
        }
        return super.shouldInterceptRequest(view,request);
      }
    });
    web.setWebChromeClient(new WebChromeClient(){
      @Override public void onPermissionRequest(PermissionRequest request){
        runOnUiThread(()->{
          boolean camera=false;
          for(String r:request.getResources()) if(PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) camera=true;
          if(!camera || !"appassets.androidplatform.net".equals(request.getOrigin().getHost())) {request.deny();return;}
          if(checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED) request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
          else { pendingCamera=request;requestPermissions(new String[]{Manifest.permission.CAMERA},CAMERA_REQ); }
        });
      }
      @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params){
        if(pendingFiles!=null) pendingFiles.onReceiveValue(null);
        pendingFiles=cb;
        try { startActivityForResult(params.createIntent(),FILE_REQ); return true; }
        catch(Exception e){pendingFiles=null;cb.onReceiveValue(null);return false;}
      }
    });
    web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
  }
  @Override public void onRequestPermissionsResult(int code,String[] permissions,int[] results){
    super.onRequestPermissionsResult(code,permissions,results);
    if(code==CAMERA_REQ && pendingCamera!=null){
      if(results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED) pendingCamera.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
      else pendingCamera.deny(); pendingCamera=null;
    }
  }
  @Override protected void onActivityResult(int req,int result,Intent data){
    super.onActivityResult(req,result,data);
    if(req==EXPORT_REQ){
      if(result==RESULT_OK&&data!=null&&data.getData()!=null){Uri target=data.getData();work.execute(()->{try{if(exportFile==null)throw new java.io.IOException("Export expired");try(InputStream in=new java.io.FileInputStream(exportFile);java.io.OutputStream out=getContentResolver().openOutputStream(target)){if(out==null)throw new java.io.IOException("Could not open destination");byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1)out.write(buffer,0,n);}exportNotice("Saved "+exportName);}catch(Exception e){exportNotice("Could not save file: "+e.getMessage());}finally{clearExport();}});}else{work.execute(()->clearExport());exportNotice("Export cancelled — no file saved");}
    }
    if(req==SCAN_REQ && result==RESULT_OK && data!=null){
      String photo=data.getStringExtra("photo"),text=data.getStringExtra("text");
      java.io.File previous=scanFile;scanFile=new java.io.File(photo);if(previous!=null&&!previous.equals(scanFile))previous.delete();
      if(web!=null)web.evaluateJavascript("window.dbzNativeScanResult("+org.json.JSONObject.quote("https://appassets.androidplatform.net/assets/native-scan.jpg?t="+System.nanoTime())+","+org.json.JSONObject.quote(text==null?"":text)+")",null);
    }
    if(req==FILE_REQ && pendingFiles!=null){pendingFiles.onReceiveValue(result==RESULT_OK?WebChromeClient.FileChooserParams.parseResult(result,data):null);pendingFiles=null;}
  }
  @Override protected void onPause(){
    if(web!=null)web.evaluateJavascript("window.dbzPauseCamera && window.dbzPauseCamera()",null);
    super.onPause();
  }
  @Override protected void onResume(){
    super.onResume();
    if(web!=null)web.evaluateJavascript("window.dbzResumeCamera && window.dbzResumeCamera(); window.dbzPricingResume && window.dbzPricingResume()",null);
  }
  @Override protected void onDestroy(){
    if(pendingCamera!=null){pendingCamera.deny();pendingCamera=null;}
    reader.close();work.execute(()->clearExport());work.shutdown();if(scanFile!=null)scanFile.delete();
    if(web!=null){web.destroy();web=null;}
    super.onDestroy();
  }
  @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
