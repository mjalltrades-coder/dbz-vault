package com.dbzvault.collector;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import java.io.InputStream;

public class MainActivity extends Activity {
  private WebView web;
  private PermissionRequest pendingCamera;
  private ValueCallback<Uri[]> pendingFiles;
  private static final int CAMERA_REQ=20, FILE_REQ=21;
  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    web=new WebView(this); setContentView(web);
    WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
    s.setAllowFileAccess(false); s.setAllowContentAccess(true); s.setMediaPlaybackRequiresUserGesture(false);
    web.setWebViewClient(new WebViewClient(){
      @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request){
        Uri uri=request.getUrl();
        if("appassets.androidplatform.net".equals(uri.getHost()) && uri.getPath()!=null && uri.getPath().startsWith("/assets/")) {
          String name=uri.getPath().substring("/assets/".length());
          if (!"index.html".equals(name)) return null;
          try { InputStream in=getAssets().open(name); return new WebResourceResponse("text/html","UTF-8",in); }
          catch(Exception ignored) { return null; }
        }
        return super.shouldInterceptRequest(view,request);
      }
    });
    web.setWebChromeClient(new WebChromeClient(){
      @Override public void onPermissionRequest(PermissionRequest request){
        runOnUiThread(()->{
          boolean camera=false;
          for(String r:request.getResources()) if(PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) camera=true;
          if(!camera || !"appassets.androidplatform.net".equals(request.getOrigin().getHost())) {request.deny();return;}
          if(checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED) request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
          else { pendingCamera=request;requestPermissions(new String[]{Manifest.permission.CAMERA},CAMERA_REQ); }
        });
      }
      @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params){
        if(pendingFiles!=null) pendingFiles.onReceiveValue(null);
        pendingFiles=cb;
        try { startActivityForResult(params.createIntent(),FILE_REQ); return true; }
        catch(Exception e){pendingFiles=null;cb.onReceiveValue(null);return false;}
      }
    });
    web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
  }
  @Override public void onRequestPermissionsResult(int code,String[] permissions,int[] results){
    super.onRequestPermissionsResult(code,permissions,results);
    if(code==CAMERA_REQ && pendingCamera!=null){
      if(results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED) pendingCamera.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
      else pendingCamera.deny(); pendingCamera=null;
    }
  }
  @Override protected void onActivityResult(int req,int result,Intent data){
    super.onActivityResult(req,result,data);
    if(req==FILE_REQ && pendingFiles!=null){pendingFiles.onReceiveValue(result==RESULT_OK?WebChromeClient.FileChooserParams.parseResult(result,data):null);pendingFiles=null;}
  }
  @Override protected void onPause(){
    if(web!=null)web.evaluateJavascript("window.dbzPauseCamera && window.dbzPauseCamera()",null);
    super.onPause();
  }
  @Override protected void onResume(){
    super.onResume();
    if(web!=null)web.evaluateJavascript("window.dbzResumeCamera && window.dbzResumeCamera()",null);
  }
  @Override protected void onDestroy(){
    if(pendingCamera!=null){pendingCamera.deny();pendingCamera=null;}
    if(web!=null){web.destroy();web=null;}
    super.onDestroy();
  }
  @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
