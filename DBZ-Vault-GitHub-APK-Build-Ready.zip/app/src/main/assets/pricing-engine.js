/* Pure pricing rules shared by the Android WebView and regression tests. */
(function(root){
'use strict';
const ranks={ebay_sold:1,tcgplayer_market:2,mna_cardz_guide:3,ebay_asking:4,manual:0};
const norm=s=>String(s||'').normalize('NFKC').replace(/[^a-z0-9]/gi,'').toUpperCase();
const fingerprint=(c,f,condition)=>JSON.stringify([c.card_number,c.line,c.set_name,c.language,c.variant||'Base',f,condition]);
const validTime=t=>typeof t==='string'&&Number.isFinite(Date.parse(t))&&Date.parse(t)<=Date.now()+86400000;
function valid(q){return !!(q&&Object.hasOwn(ranks,q.source)&&Number.isFinite(q.original_price)&&q.original_price>0&&Number.isFinite(q.exchange_rate_to_aud)&&q.exchange_rate_to_aud>0&&Number.isFinite(q.price)&&q.price>0&&Math.abs(q.price-Math.round(q.original_price*q.exchange_rate_to_aud*100)/100)<.011&&/^[A-Z]{3}$/.test(q.original_currency)&&validTime(q.observed_at)&&validTime(q.checked)&&validTime(q.fx_date)&&q.fx_source&&q.fingerprint&&safeURL(q.source_url,q.source));}
function safeURL(url,source){try{const u=new URL(url);const h=u.hostname.replace(/^www\./,'');return u.protocol==='https:'&&!u.username&&!u.password&&((source==='ebay_sold'||source==='ebay_asking')?u.pathname.startsWith('/itm/'):source==='tcgplayer_market'?u.pathname.startsWith('/product/'):source==='mna_cardz_guide'?u.pathname.startsWith('/products/'):false)&&({ebay_sold:['ebay.com.au','ebay.com','ebay.co.uk','ebay.ca','ebay.de','ebay.fr','ebay.it','ebay.es','ebay.ie','ebay.nl','ebay.at','ebay.ch','ebay.be','ebay.pl','ebay.com.hk','ebay.com.sg'],tcgplayer_market:['tcgplayer.com'],mna_cardz_guide:['mnacardz.com']}[source==='ebay_asking'?'ebay_sold':source]||[]).includes(h);}catch(e){return false;}}
function choose(old,candidate){
 if(!valid(candidate))return {status:'no_match',value:old};
 if(old&&(old.user_confirmed||old.source==='manual'||(ranks[old.source]??0)<ranks[candidate.source]))return {status:'review',value:old,suggestion:candidate};
 if(old&&old.source==='tcgplayer_market'&&!old.normal_price_fallback&&candidate.normal_price_fallback)return {status:'review',value:old,suggestion:candidate};
 if(old&&validTime(old.observed_at)&&Date.parse(candidate.observed_at)<Date.parse(old.observed_at))return {status:'older',value:old};
 return {status:'updated',value:candidate};
}
function tcg(c,f,condition,feed,checked){
 if(c.language!=='English'||condition!=='Raw / Near Mint'||(c.variant||'Base')!=='Base'||!feed?.quotes)return null;
 const matches=(q,finish)=>q&&q.line===c.line&&q.language===c.language&&q.finish===finish&&norm(q.name)===norm(c.name)&&norm(q.set)===norm(c.set_name)&&Number.isSafeInteger(q.productId);
 let q=feed.quotes[c.card_number+'@@'+f],fallback=false;
 if(!matches(q,f)&&f==='Foil'){q=feed.quotes[c.card_number+'@@Normal'];fallback=true;}
 if(!matches(q,fallback?'Normal':f))return null;
 const r={price:q.aud,source:'tcgplayer_market',price_type:'recent_sales_aggregate',original_currency:'USD',original_price:q.usd,exchange_rate_to_aud:feed.usdToAud,fx_source:feed.fxSource||'Frankfurter',fx_date:feed.fxDate,source_url:'https://www.tcgplayer.com/product/'+q.productId,observed_at:feed.updated,checked,fingerprint:fingerprint(c,f,condition),condition_basis:'Product-level market aggregate; condition-specific data unavailable',normal_price_fallback:fallback,source_finish:q.sourceFinish||q.finish,auto:true};
 return valid(r)?r:null;
}
function mna(c,f,condition,data,mapping,checked){
 if(!mapping||mapping.source==='tcgplayer_market'||mapping.fingerprint!==fingerprint(c,f,condition))return null;
 const q=data?.records?.find(q=>q.source_record_id===mapping.product_id);
 if(!q||!q.card_code||norm(q.card_code)!==norm(c.printed_number||c.card_number)||q.variant_count!==1)return null;
 const r={price:q.guide_price_aud,source:'mna_cardz_guide',price_type:'retailer_asking_price_guide',original_currency:'USD',original_price:q.source_price_usd,exchange_rate_to_aud:q.fx_usd_to_aud,fx_date:q.fx_rate_as_of,fx_source:'Supplied MNA snapshot conversion',source_url:q.source_url,observed_at:q.snapshot_date,checked,fingerprint:mapping.fingerprint,source_record_id:q.source_record_id,auto:true,snapshot:true};return valid(r)?r:null;
}
function tcgChoices(c,feed){
 if(c.language!=='English')return [];
 let rows=feed?.candidates?.[c.card_number]||[];
 // Older server feeds can still update a pinned original product, but never guess an alternate printing.
 if((feed?.matcherVersion||1)<4){rows=['Normal','Foil'].map(f=>feed?.quotes?.[c.card_number+'@@'+f]).filter(Boolean).map(q=>({...q,card_number:c.card_number,sourceFinish:q.sourceFinish||q.finish,source_url:'https://www.tcgplayer.com/product/'+q.productId}));rows=rows.filter((q,i)=>rows.findIndex(x=>x.productId===q.productId&&x.sourceFinish===q.sourceFinish)===i);}
 return rows.filter(q=>q.card_number===c.card_number&&q.line===c.line&&q.language===c.language&&norm(q.set)===norm(c.set_name)&&Number.isSafeInteger(q.productId)&&q.productId>0&&['Normal','Foil','Holofoil','Parallel Foil'].includes(q.sourceFinish)&&Number.isFinite(q.usd)&&q.usd>0&&Number.isFinite(q.aud)&&q.aud>0&&Math.abs(q.aud-Math.round(q.usd*feed.usdToAud*100)/100)<.011&&safeURL(q.source_url,'tcgplayer_market'));
}
function selectedTcg(c,f,condition,feed,mapping,checked){
 if(!mapping||mapping.source!=='tcgplayer_market'||mapping.confirmed!==true||mapping.fingerprint!==fingerprint(c,f,condition)||condition!=='Raw / Near Mint')return null;
 const product=tcgChoices(c,feed).filter(q=>q.productId===mapping.product_id);
 let rows=product.filter(q=>q.sourceFinish===mapping.source_finish);
 if(f==='Foil'&&mapping.source_finish==='Normal'){const foil=product.filter(q=>['Foil','Holofoil'].includes(q.sourceFinish));if(foil.length===1)rows=foil;}
 if(!rows.length&&f==='Foil')rows=product.filter(q=>q.sourceFinish==='Normal');
 if(rows.length!==1)return null;const q=rows[0];
 const r={price:q.aud,source:'tcgplayer_market',price_type:'recent_sales_aggregate',original_currency:'USD',original_price:q.usd,exchange_rate_to_aud:feed.usdToAud,fx_source:feed.fxSource||'Frankfurter',fx_date:feed.fxDate,source_url:q.source_url,observed_at:feed.updated,checked,fingerprint:fingerprint(c,f,condition),condition_basis:'User confirmed product/printing; product-level market aggregate, not condition-specific',product_id:q.productId,product_name:q.name,source_finish:q.sourceFinish,normal_price_fallback:f==='Foil'&&q.sourceFinish==='Normal',identity_confirmed:true,auto:true};
 return valid(r)?r:null;
}
function due(last,now=Date.now()){return !Number.isFinite(Date.parse(last))||now-Date.parse(last)>=30*86400000;}
root.DBZPricing={ranks,norm,fingerprint,valid,safeURL,choose,tcg,mna,tcgChoices,selectedTcg,due};
if(typeof module!=='undefined')module.exports=root.DBZPricing;
})(typeof window!=='undefined'?window:globalThis);
