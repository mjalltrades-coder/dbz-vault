DBZ Vault Camera Fix 0.2

Installs alongside DBZ Vault for testing without deleting its collection.
The collection remains in the original app; export/import a backup to move it.

Camera changes:
- Resume the scanner after temporary Android permission/background interruptions.
- Ignore cancelled or outdated camera requests.
- Render the camera into a canvas to avoid WebView video overlay blackouts.
- Recover ended/stalled streams with bounded retries and a Restart camera button.
- Keep the green centre crop for OCR; release camera on Cancel/background.

Validated JavaScript parsing and mocked lifecycle regression tests.
Physical Android camera verification still required.
